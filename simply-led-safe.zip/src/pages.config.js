/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import AboutUs from './pages/AboutUs';
import AdBundle from './pages/AdBundle';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import Cyclists from './pages/Cyclists';
import Follow from './pages/Follow';
import Home from './pages/Home';
import Joggers from './pages/Joggers';
import NightSafety from './pages/NightSafety';
import Pets from './pages/Pets';
import PinterestBoards from './pages/PinterestBoards';
import PinterestPins from './pages/PinterestPins';
import PinterestVerification from './pages/PinterestVerification';
import Promo from './pages/Promo';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AboutUs": AboutUs,
    "AdBundle": AdBundle,
    "Blog": Blog,
    "BlogPost": BlogPost,
    "Cyclists": Cyclists,
    "Follow": Follow,
    "Home": Home,
    "Joggers": Joggers,
    "NightSafety": NightSafety,
    "Pets": Pets,
    "PinterestBoards": PinterestBoards,
    "PinterestPins": PinterestPins,
    "PinterestVerification": PinterestVerification,
    "Promo": Promo,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};