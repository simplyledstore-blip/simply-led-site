import React from "react";
import { motion } from "framer-motion";
import { Check, X, ArrowLeftRight } from "lucide-react";

const products = [
  {
    id: 0,
    title: "BLITZU 4 Pack",
    image: "https://m.media-amazon.com/images/I/8193jO2xkDL._AC_SX679_.jpg",
    affiliateUrl: "https://amzn.to/3O73kv3",
    brightness: "High",
    batteryLife: "Up to 100 hrs",
    quantity: "4 lights",
    modes: "Steady, Fast Strobe, Slow Flash",
    weatherResistant: true,
    reflectiveBand: false,
    multiColor: false,
    bestFor: "Runners, kids, everyday walkers",
    price: "$",
  },
  {
    id: 1,
    title: "Apace Vision 2 Pack",
    image: "https://m.media-amazon.com/images/I/81VolVxnHqL._AC_SX679_.jpg",
    affiliateUrl: "https://a.co/d/0eWNFmQo",
    brightness: "Medium-High",
    batteryLife: "Up to 60 hrs",
    quantity: "2 lights",
    modes: "Steady, Strobe",
    weatherResistant: true,
    reflectiveBand: true,
    multiColor: false,
    bestFor: "Dog walkers, strollers, cyclists",
    price: "$$",
  },
  {
    id: 2,
    title: "9 Pack Multi-Color",
    image: "https://m.media-amazon.com/images/I/81-Yd4d3vzL._AC_SX679_.jpg",
    affiliateUrl: "https://a.co/d/05drSSZs",
    brightness: "Medium",
    batteryLife: "Up to 80 hrs",
    quantity: "9 lights",
    modes: "Strobe",
    weatherResistant: false,
    reflectiveBand: false,
    multiColor: true,
    bestFor: "Groups, families, school events",
    price: "$",
  },
];

const rows = [
  { label: "Quantity", key: "quantity" },
  { label: "Brightness", key: "brightness" },
  { label: "Battery Life", key: "batteryLife" },
  { label: "Light Modes", key: "modes" },
  { label: "Price Range", key: "price" },
  { label: "Best For", key: "bestFor" },
  { label: "Weather Resistant", key: "weatherResistant", boolean: true },
  { label: "Reflective Band Included", key: "reflectiveBand", boolean: true },
  { label: "Multi-Color", key: "multiColor", boolean: true },
];

export default function CompareSection() {
  return (
    <section className="py-20 sm:py-28 border-t border-white/5">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-yellow-400/10 border border-yellow-400/20 mb-4">
            <ArrowLeftRight className="w-3.5 h-3.5 text-yellow-400" />
            <span className="text-xs font-medium text-yellow-400 tracking-wide uppercase">Compare</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">Compare LED Safety Lights</h2>
          <p className="mt-3 text-gray-400 max-w-xl mx-auto">
            See how our top picks stack up side by side.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-2xl border border-white/[0.06] overflow-hidden"
        >
          {/* Header */}
          <div className="grid bg-white/[0.04] border-b border-white/5" style={{gridTemplateColumns:'1fr 1fr 1fr 1fr'}}>
            <div className="p-4 text-xs text-gray-500 uppercase tracking-wider font-semibold flex items-center">Feature</div>
            {products.map((p) => (
              <div key={p.id} className="p-4 text-center border-l border-white/5">
                <img src={p.image} alt={p.title} className="w-14 h-14 object-contain mx-auto mb-2" />
                <p className="text-white font-semibold text-sm">{p.title}</p>
                <a
                  href={p.affiliateUrl}
                  target="_blank"
                  rel="noopener noreferrer nofollow"
                  className="inline-block mt-1 text-xs text-yellow-400 hover:underline"
                >
                  View on Amazon →
                </a>
              </div>
            ))}
          </div>

          {/* Rows */}
          {rows.map((row, i) => (
            <div
              key={row.key}
              className={`grid border-b border-white/5 last:border-0 ${i % 2 === 0 ? "bg-white/[0.01]" : ""}`}
              style={{gridTemplateColumns:'1fr 1fr 1fr 1fr'}}
            >
              <div className="p-4 text-sm text-gray-400 font-medium flex items-center">{row.label}</div>
              {products.map((p) => (
                <div key={p.id} className="p-4 text-center border-l border-white/5 flex items-center justify-center">
                  {row.boolean ? (
                    p[row.key] ? (
                      <Check className="w-4 h-4 text-green-400" />
                    ) : (
                      <X className="w-4 h-4 text-gray-600" />
                    )
                  ) : (
                    <span className="text-sm text-white">{p[row.key]}</span>
                  )}
                </div>
              ))}
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}