import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { ArrowRight } from "lucide-react";

const useCases = [
  {
    title: "Joggers at Night",
    description: "Be visible from 1,000+ feet away. Clip lights to your jacket, shoes, or armband and run with confidence on any road.",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/699b88467_shoes_straps_clothes.png",
    page: "Joggers",
    accent: "from-yellow-400/20",
  },
  {
    title: "For Your Pet",
    description: "Attach to collars, leashes, or harnesses. Keep your furry companion visible to drivers and other pedestrians after dark.",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/1aa997c4e_petledlight.png",
    page: "Pets",
    accent: "from-green-400/20",
  },
  {
    title: "Cyclists on the Road",
    description: "Clip to helmets, backpacks, or bike frames for 360° visibility. Multiple light modes for any riding condition.",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/2f44ba8e5_helmet_backpack_cycle.png",
    page: "Cyclists",
    accent: "from-blue-400/20",
  },
];

export default function UseCaseSection() {
  return (
    <section className="py-20 sm:py-28 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            Who Are These Lights For?
          </h2>
          <p className="mt-3 text-gray-400 max-w-xl mx-auto">
            LED clip-on lights are essential safety gear for anyone active after dark.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {useCases.map((useCase, index) => (
            <motion.div
              key={useCase.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Link
                to={createPageUrl(useCase.page)}
                className="group block relative rounded-2xl overflow-hidden border border-white/[0.06] hover:border-yellow-400/20 transition-all duration-500 h-full"
              >
                {/* Image */}
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={useCase.image}
                    alt={useCase.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${useCase.accent} via-transparent to-transparent opacity-40`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f]/40 to-transparent" />
                </div>

                {/* Title at top */}
                <div className="absolute top-0 left-0 right-0 p-6">
                  <h3 className="text-xl font-bold text-white">
                    {useCase.title}
                  </h3>
                </div>

                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="text-xl font-bold text-white mb-2 sr-only">
                    {useCase.title}
                  </h3>
                  <p className="text-sm text-gray-400 leading-relaxed mb-4">
                    {useCase.description}
                  </p>
                  <div className="flex items-center gap-2 text-yellow-400 text-sm font-medium group-hover:gap-3 transition-all">
                    <span>Learn more</span>
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}