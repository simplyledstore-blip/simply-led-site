import React, { useState } from "react";
import { motion } from "framer-motion";
import { Lightbulb, ChevronLeft, ChevronRight } from "lucide-react";

export default function VideoSection() {
  const slides = [
    "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/d819d87c3_slide1.jpg",
    "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/92a04433d_slide2.jpg",
    "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/3f42fbc67_slide3.jpg",
    "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/4de53b0b9_slide4.jpg",
    "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/b064b82cf_slide5.jpg",
    "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/69b7c9150_slide6.jpg",
    "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/c679076e3_slide7.jpg",
  ];

  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  return (
    <section className="py-20 sm:py-28">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-yellow-400/10 border border-yellow-400/20 mb-4">
            <Lightbulb className="w-3.5 h-3.5 text-yellow-400" />
            <span className="text-xs font-medium text-yellow-400 tracking-wide uppercase">Watch Demo</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            How LED Clip-On Lights Work
          </h2>
          <p className="mt-3 text-gray-400 max-w-xl mx-auto">
            See how easily these lights attach to clothing, pet collars, and gear for instant visibility in low-light situations.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="relative w-full mx-auto"
          style={{ maxWidth: '1100px' }}
        >
          <div 
            className="relative aspect-video rounded-2xl overflow-hidden border border-yellow-400/20 bg-[#0b0f1a]"
            style={{ borderRadius: '16px' }}
          >
            {/* Slide Display */}
            <div className="relative w-full h-full">
              {slides.map((slide, index) => (
                <img
                  key={index}
                  src={slide}
                  alt={`LED Safety Light Feature ${index + 1}`}
                  className="absolute inset-0 w-full h-full object-contain transition-opacity duration-500"
                  style={{
                    opacity: currentSlide === index ? 1 : 0,
                    pointerEvents: currentSlide === index ? 'auto' : 'none',
                  }}
                />
              ))}
            </div>

            {/* Navigation Arrows */}
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 border border-yellow-400/30 flex items-center justify-center hover:bg-yellow-400/20 transition-all duration-300 z-10"
              aria-label="Previous slide"
            >
              <ChevronLeft className="w-5 h-5 text-yellow-400" />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 border border-yellow-400/30 flex items-center justify-center hover:bg-yellow-400/20 transition-all duration-300 z-10"
              aria-label="Next slide"
            >
              <ChevronRight className="w-5 h-5 text-yellow-400" />
            </button>

            {/* Dot Indicators */}
            <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 z-10">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    currentSlide === index
                      ? 'bg-yellow-400 w-8'
                      : 'bg-gray-500 hover:bg-gray-400'
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}