import React from "react";
import { motion } from "framer-motion";
import { ExternalLink, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ProductCard({ product, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.15 }}
      className="group relative bg-gradient-to-b from-white/[0.04] to-transparent rounded-2xl border border-white/[0.06] overflow-hidden hover:border-yellow-400/20 transition-all duration-500"
    >
      {/* Image */}
      <div className="relative aspect-[4/3] bg-gradient-to-b from-white/[0.02] to-transparent p-6 flex items-center justify-center overflow-hidden">
        <img
          src={product.image}
          alt={product.title}
          className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="p-6 pt-2">
        {/* Title */}
        <h3 className="text-lg font-semibold text-white mb-4 leading-snug">
          {product.title}
        </h3>

        {/* Review Text */}
        <p className="text-sm text-gray-400 leading-relaxed mb-5">
          {product.reviewText}
        </p>

        {/* Benefits */}
        <ul className="space-y-2 mb-6">
          {product.benefits.map((benefit, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
              <Check className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
              <span>{benefit}</span>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <a
          href={product.affiliateUrl}
          target="_blank"
          rel="noopener noreferrer nofollow"
          className="block"
        >
          <Button className="w-full bg-yellow-400 hover:bg-yellow-300 text-black font-semibold py-6 rounded-xl glow-btn transition-all duration-300 text-sm">
            View on Amazon
            <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
        </a>

        <p className="text-[10px] text-gray-600 text-center mt-3">
          As an Amazon Associate we earn from qualifying purchases
        </p>
      </div>
    </motion.div>
  );
}