import React from "react";
import { motion } from "framer-motion";
import { Check, ExternalLink, Shield, Zap, Moon, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Joggers() {
  const tips = [
    "Attach LED lights to both front and back of your body for 360° visibility",
    "Use strobe mode on busy roads — it catches drivers' attention faster",
    "Clip a light to each shoe for a moving, eye-catching effect",
    "Pair LED lights with reflective clothing for maximum safety",
    "Replace batteries regularly — dim lights defeat the purpose",
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1552674605-db6ffd4facb5?w=1400&q=80"
            alt="Night jogger"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-[#0a0a0f]/80 to-[#0a0a0f]" />
        </div>

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-36 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-yellow-400/10 border border-yellow-400/20 mb-6">
              <Moon className="w-3.5 h-3.5 text-yellow-400" />
              <span className="text-xs font-medium text-yellow-400 tracking-wide uppercase">Night Running Safety</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight">
              Run the Night,<br />
              <span className="text-yellow-400 glow-text">Own Your Visibility</span>
            </h1>
            <p className="mt-6 text-lg text-gray-400 max-w-2xl mx-auto">
              Every year, thousands of joggers are involved in road accidents after dark. A small LED clip-on light can make you visible from over 1,000 feet away.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Why LED Lights for Joggers */}
      <section className="py-20 border-t border-white/5">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-white mb-6">
                Why Every Jogger Needs LED Clip-On Lights
              </h2>
              <p className="text-gray-400 leading-relaxed mb-6">
                Whether you're training for a marathon or enjoying a casual evening run, visibility is everything. LED clip-on safety lights are lightweight, weather-resistant, and take seconds to attach to your gear.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                {[
                  { icon: Zap, label: "Instant Visibility", desc: "Seen from 1,000+ ft" },
                  { icon: Shield, label: "Weather Resistant", desc: "Rain or shine" },
                  { icon: Moon, label: "Multiple Modes", desc: "Steady, strobe, flash" },
                ].map((item, i) => (
                  <div key={i} className="p-4 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                    <item.icon className="w-5 h-5 text-yellow-400 mb-2" />
                    <p className="text-sm font-semibold text-white">{item.label}</p>
                    <p className="text-xs text-gray-500">{item.desc}</p>
                  </div>
                ))}
              </div>
              <a
                href="https://amzn.to/3O73kv3"
                target="_blank"
                rel="noopener noreferrer nofollow"
              >
                <Button className="bg-yellow-400 hover:bg-yellow-300 text-black font-semibold py-6 px-8 rounded-xl glow-btn">
                  View on Amazon
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="rounded-2xl overflow-hidden border border-white/[0.06]">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/3e2b2a64d_JOGGERRUNNINGWITHLED.png"
                  alt="Jogger at night"
                  className="w-full h-auto"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Tips */}
      <section className="py-20 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-white">Night Running Safety Tips</h2>
          </motion.div>

          <div className="space-y-4">
            {tips.map((tip, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="flex items-start gap-4 p-5 rounded-xl bg-white/[0.02] border border-white/[0.06] hover:border-yellow-400/20 transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-yellow-400/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check className="w-4 h-4 text-yellow-400" />
                </div>
                <p className="text-gray-300">{tip}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}