import React from "react";
import { motion } from "framer-motion";
import { Check, ExternalLink, Bike, AlertTriangle, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Cyclists() {
  const placements = [
    { area: "Helmet", tip: "Clip to the back or side for headlight-level visibility to cars behind you" },
    { area: "Backpack", tip: "Attach to bag straps or the rear pocket for a high-mounted light source" },
    { area: "Seat Post", tip: "Clip near your seat as a secondary rear light for extra safety" },
    { area: "Spokes / Frame", tip: "Attach to wheel spokes or frame tubes for side visibility at intersections" },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/c3e93bd46_cycleLEDandcyclist.png"
            alt="Cycling at night"
            className="w-full h-full object-contain opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-[#0a0a0f]/80 to-[#0a0a0f]" />
        </div>

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-36 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-400/10 border border-blue-400/20 mb-6">
              <Bike className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-xs font-medium text-blue-400 tracking-wide uppercase">Cyclist Safety</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight">
              Ride Visible,<br />
              <span className="text-blue-400" style={{ textShadow: "0 0 20px rgba(96,165,250,0.4)" }}>Ride Confident</span>
            </h1>
            <p className="mt-6 text-lg text-gray-400 max-w-2xl mx-auto">
              Cyclists are among the most vulnerable road users after dark. LED clip-on lights add critical 360° visibility in seconds.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Why Cyclists */}
      <section className="py-20 border-t border-white/5">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-white mb-4">
                Beyond Your Bike Light
              </h2>
              <p className="text-gray-400 leading-relaxed mb-4">
                Your primary bike light covers the front and rear, but what about side visibility? Intersections, driveways, and parking lots are where most cycling accidents happen. LED clip-on lights fill those blind spots.
              </p>
              <p className="text-gray-400 leading-relaxed mb-6">
                They're also a perfect backup — lightweight, battery-powered, and ready when your main light dies unexpectedly.
              </p>

              <div className="flex items-start gap-3 p-4 rounded-xl bg-yellow-400/5 border border-yellow-400/20 mb-8">
                <AlertTriangle className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-gray-300">
                  <strong className="text-yellow-400">Did you know?</strong> Over 850 cyclists are killed in traffic crashes annually in the U.S. Most fatal crashes occur between 6 PM and 9 PM.
                </p>
              </div>

              <a
                href="https://amzn.to/3O73kv3"
                target="_blank"
                rel="noopener noreferrer nofollow"
              >
                <Button className="bg-blue-500 hover:bg-blue-400 text-white font-semibold py-6 px-8 rounded-xl transition-all duration-300 shadow-lg shadow-blue-500/20">
                  View on Amazon
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="rounded-2xl overflow-hidden border border-white/[0.06]">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/c3e93bd46_cycleLEDandcyclist.png"
                  alt="Cyclist on road"
                  className="w-full h-auto"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Where to Clip */}
      <section className="py-20 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold text-white">Where to Clip Your Lights</h2>
            <p className="mt-2 text-gray-400">Strategic placement maximizes your visibility from all angles.</p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {placements.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="p-5 rounded-xl bg-white/[0.02] border border-white/[0.06] hover:border-blue-400/20 transition-colors"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-full bg-blue-400/10 flex items-center justify-center">
                    <Eye className="w-4 h-4 text-blue-400" />
                  </div>
                  <h3 className="font-semibold text-white">{item.area}</h3>
                </div>
                <p className="text-sm text-gray-400 ml-11">{item.tip}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}