import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Download, Lock, Loader2, CheckCircle } from "lucide-react";

function buildHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>SimplyLED Store — LED Safety Lights for Night Visibility</title>
<meta name="description" content="Honest reviews and curated picks for the best LED clip-on safety lights. Stay visible and safe during night walks, runs, cycling, and dog walks."/>
<meta property="og:title" content="SimplyLED Store — LED Safety Lights for Night Visibility"/>
<meta property="og:description" content="Stay visible and safe at night. Curated LED clip-on safety lights for walkers, runners, cyclists, and pets."/>
<meta property="og:image" content="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/a7e7fb818_SLS-LOGO1.png"/>
<meta property="og:type" content="website"/>
<meta name="twitter:card" content="summary_large_image"/>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{background:#0a0a0f;color:#fff;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;line-height:1.6;}
a{color:inherit;text-decoration:none;}
nav{position:fixed;top:0;left:0;right:0;z-index:100;background:rgba(10,10,15,0.92);backdrop-filter:blur(12px);border-bottom:1px solid rgba(255,255,255,0.05);padding:0 24px;}
.nav-inner{max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;height:64px;}
.nav-logo img{height:42px;}
.nav-links{display:flex;gap:4px;}
.nav-links a{padding:8px 16px;border-radius:99px;font-size:14px;font-weight:500;color:#9ca3af;transition:all .2s;}
.nav-links a:hover,.nav-links a.active{background:rgba(250,204,21,0.1);color:#facc15;border:1px solid rgba(250,204,21,0.2);}
.nav-links a{border:1px solid transparent;}
main{padding-top:64px;}
.page{display:none;}
.page.active{display:block;}
.hero{padding:80px 24px 60px;text-align:center;position:relative;}
.hero-bg{position:absolute;inset:0;overflow:hidden;pointer-events:none;}
.hero-blob{position:absolute;border-radius:50%;filter:blur(80px);opacity:.15;}
.hero-blob-1{width:400px;height:400px;background:#facc15;top:-100px;left:50%;transform:translateX(-40%);}
.hero-blob-2{width:300px;height:300px;background:#3b82f6;bottom:0;right:10%;}
.container{max-width:1200px;margin:0 auto;padding:0 24px;}
.badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:99px;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;margin-bottom:20px;}
.badge-yellow{background:rgba(250,204,21,0.1);border:1px solid rgba(250,204,21,0.2);color:#facc15;}
.badge-red{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#f87171;}
h1{font-size:clamp(2rem,5vw,3.5rem);font-weight:800;line-height:1.15;margin-bottom:16px;}
h2{font-size:clamp(1.5rem,3vw,2.2rem);font-weight:700;margin-bottom:12px;}
.accent{color:#facc15;}
.subtitle{color:#6b7280;font-size:1.1rem;max-width:600px;margin:0 auto 32px;}
.btn{display:inline-flex;align-items:center;gap:8px;padding:14px 32px;border-radius:12px;font-weight:600;font-size:15px;cursor:pointer;transition:all .3s;border:none;}
.btn-yellow{background:#facc15;color:#000;}
.btn-yellow:hover{background:#fde047;box-shadow:0 0 25px rgba(250,204,21,0.4);}
.btn-outline{background:transparent;color:#facc15;border:1px solid rgba(250,204,21,0.3);}
.section{padding:60px 0;border-top:1px solid rgba(255,255,255,0.05);}
.grid-3{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;}
.grid-2{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:24px;}
.card{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:20px;overflow:hidden;}
.card-img{width:100%;height:200px;object-fit:contain;background:#111118;padding:20px;}
.card-body{padding:20px;}
.card-title{font-size:1rem;font-weight:700;margin-bottom:8px;}
.card-text{font-size:.875rem;color:#6b7280;line-height:1.6;}
.feature-list{list-style:none;margin:12px 0 20px;}
.feature-list li{font-size:.8rem;color:#9ca3af;padding:3px 0;}
.feature-list li::before{content:"✓ ";color:#facc15;}
.text-center{text-align:center;}
.mb-12{margin-bottom:48px;}
.stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:16px;margin-top:32px;}
.stat-card{text-align:center;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:16px;padding:20px;}
.stat-num{font-size:2rem;font-weight:800;color:#facc15;}
.stat-label{font-size:.8rem;color:#6b7280;margin-top:4px;}
footer{border-top:1px solid rgba(255,255,255,0.05);background:#060609;padding:48px 24px;}
.footer-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:32px;max-width:1200px;margin:0 auto;}
.footer-title{font-size:.75rem;font-weight:600;color:#d1d5db;text-transform:uppercase;letter-spacing:.1em;margin-bottom:16px;}
.footer-link{display:block;font-size:.875rem;color:#6b7280;margin-bottom:8px;transition:color .2s;}
.footer-link:hover{color:#facc15;}
.footer-bottom{text-align:center;margin-top:32px;padding-top:24px;border-top:1px solid rgba(255,255,255,0.05);font-size:.75rem;color:#374151;}
.disclosure{font-size:.75rem;color:#374151;line-height:1.6;}
.tip-box{border:1px solid rgba(250,204,21,0.2);background:rgba(250,204,21,0.05);border-radius:20px;padding:24px;margin-top:32px;}
.tip-title{color:#facc15;font-weight:700;font-size:.875rem;text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px;}
.tip-list{list-style:disc;padding-left:20px;color:#6b7280;font-size:.875rem;}
.tip-list li{margin-bottom:6px;}
@media(max-width:768px){.nav-links{display:none;}}
</style>
</head>
<body>
<nav>
  <div class="nav-inner">
    <a href="#" class="nav-logo" onclick="showPage('home')">
      <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/a7e7fb818_SLS-LOGO1.png" alt="SimplyLED Store"/>
    </a>
    <div class="nav-links">
      <a href="#" onclick="showPage('home')" id="nav-home" class="active">Home</a>
      <a href="#" onclick="showPage('joggers')" id="nav-joggers">Joggers</a>
      <a href="#" onclick="showPage('pets')" id="nav-pets">Pets</a>
      <a href="#" onclick="showPage('cyclists')" id="nav-cyclists">Cyclists</a>
      <a href="#" onclick="showPage('about')" id="nav-about">About Us</a>
    </div>
  </div>
</nav>

<main>

<!-- HOME PAGE -->
<div id="page-home" class="page active">
  <div class="hero">
    <div class="hero-bg"><div class="hero-blob hero-blob-1"></div><div class="hero-blob hero-blob-2"></div></div>
    <div style="position:relative">
      <div class="badge badge-yellow">⚡ #1 Night Safety Resource</div>
      <h1>Stay Visible.<br/><span class="accent">Stay Alive.</span></h1>
      <p class="subtitle">The best LED clip-on safety lights for night walks, runs, cycling, and dog walks — curated, tested, and reviewed.</p>
      <a href="https://amzn.to/3O73kv3" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow">Shop on Amazon →</a>
    </div>
  </div>

  <div class="section">
    <div class="container">
      <div class="text-center mb-12">
        <div class="badge badge-yellow">Featured Products</div>
        <h2>Popular LED Clip-On Safety Lights</h2>
        <p style="color:#6b7280;max-width:500px;margin:8px auto 0">Practical information about popular LED clip-on safety lights for night visibility.</p>
      </div>
      <div class="grid-3">
        <div class="card">
          <img class="card-img" src="https://m.media-amazon.com/images/I/8193jO2xkDL._AC_SX679_.jpg" alt="BLITZU 4 Pack LED Safety Light"/>
          <div class="card-body">
            <p class="card-title">BLITZU 4 Pack LED Safety Light</p>
            <p class="card-text">The BLITZU 4-pack includes batteries pre-installed and extras for replacement. Each light offers 3 modes — steady, fast strobe, and slow flash.</p>
            <ul class="feature-list">
              <li>4 bright LED lights in one pack</li>
              <li>3 light modes: steady, fast strobe, slow flash</li>
              <li>Batteries included — up to 100 hours</li>
              <li>Durable clip-on design fits clothing, bags &amp; gear</li>
              <li>Weather-resistant construction</li>
            </ul>
            <a href="https://amzn.to/3O73kv3" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow" style="font-size:13px;padding:10px 20px">View on Amazon →</a>
          </div>
        </div>
        <div class="card">
          <img class="card-img" src="https://m.media-amazon.com/images/I/81VolVxnHqL._AC_SX679_.jpg" alt="Apace Vision LED Safety Light"/>
          <div class="card-body">
            <p class="card-title">Apace Vision LED Safety Light (2 Pack)</p>
            <p class="card-text">The Apace Vision 2-pack features a strong clip and compact design perfect for dog walkers and stroller parents. Includes bonus reflective band.</p>
            <ul class="feature-list">
              <li>Compact &amp; lightweight</li>
              <li>Bonus reflective band included</li>
              <li>Versatile: dogs, bikes, strollers, boats</li>
              <li>Reliable strobe and steady modes</li>
              <li>Secure attachment mechanism</li>
            </ul>
            <a href="https://a.co/d/0eWNFmQo" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow" style="font-size:13px;padding:10px 20px">View on Amazon →</a>
          </div>
        </div>
        <div class="card">
          <img class="card-img" src="https://m.media-amazon.com/images/I/81-Yd4d3vzL._AC_SX679_.jpg" alt="9 Pack LED Safety Light"/>
          <div class="card-body">
            <p class="card-title">9 Pack LED Safety Light (Multi-Color)</p>
            <p class="card-text">This 9-pack comes in red, blue, and green — perfect for color-coding family members or gear. Lightweight and easy to clip anywhere.</p>
            <ul class="feature-list">
              <li>9 lights in one pack — ideal for groups</li>
              <li>3 colors for easy identification</li>
              <li>Clip-on design fits clothes, wrists, and bags</li>
              <li>Great for families, school groups &amp; camping</li>
              <li>High visibility strobe</li>
            </ul>
            <a href="https://a.co/d/05drSSZs" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow" style="font-size:13px;padding:10px 20px">View on Amazon →</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="container text-center">
      <h2>Don't Wait Until It's Too Late</h2>
      <p style="color:#6b7280;margin:12px auto 32px;max-width:500px">Over 2,000 pedestrians are injured every week in low-visibility conditions. A simple LED light can make all the difference.</p>
      <a href="https://amzn.to/3O73kv3" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow">View on Amazon →</a>
    </div>
  </div>
</div>

<!-- JOGGERS PAGE -->
<div id="page-joggers" class="page">
  <div class="hero">
    <div class="badge badge-yellow">🏃 For Runners &amp; Joggers</div>
    <h1>Run Safer.<br/><span class="accent">Run Smarter.</span></h1>
    <p class="subtitle">LED clip-on lights keep you visible during early morning and evening runs. Don't let poor lighting stop your training.</p>
    <a href="https://amzn.to/3O73kv3" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow">Shop Safety Lights →</a>
  </div>
  <div class="section">
    <div class="container">
      <div class="grid-3">
        <div class="card" style="padding:24px">
          <div style="font-size:2rem;margin-bottom:12px">⚡</div>
          <p class="card-title">100+ Hour Battery</p>
          <p class="card-text">Runs all season on one set of batteries. Never worry about running out mid-run.</p>
        </div>
        <div class="card" style="padding:24px">
          <div style="font-size:2rem;margin-bottom:12px">🛡️</div>
          <p class="card-title">Weather Resistant</p>
          <p class="card-text">Works in rain, fog, and cold nights. Built to handle any outdoor condition.</p>
        </div>
        <div class="card" style="padding:24px">
          <div style="font-size:2rem;margin-bottom:12px">⭐</div>
          <p class="card-title">3 Light Modes</p>
          <p class="card-text">Steady, fast strobe &amp; slow flash — choose the mode that fits your run.</p>
        </div>
      </div>
      <div class="tip-box" style="margin-top:32px">
        <p class="tip-title">🏃 Night Running Safety Tips</p>
        <ul class="tip-list">
          <li>Clip lights to both front and back for 360° visibility</li>
          <li>Wear one on your wrist so hand motions are visible to drivers</li>
          <li>Run against traffic so you can see oncoming cars</li>
          <li>Stick to well-lit routes and vary your path regularly</li>
          <li>Tell someone your route and estimated return time</li>
        </ul>
      </div>
      <div style="text-align:center;margin-top:40px">
        <a href="https://amzn.to/3O73kv3" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow">Get Your Safety Light on Amazon →</a>
      </div>
    </div>
  </div>
</div>

<!-- PETS PAGE -->
<div id="page-pets" class="page">
  <div class="hero">
    <div class="badge badge-yellow">🐾 For Pet Owners</div>
    <h1>Keep Your Pet<br/><span class="accent">Visible &amp; Safe.</span></h1>
    <p class="subtitle">Clip-on LED lights for dogs and cats mean drivers see your pet from 300+ feet away. Simple, affordable, life-saving.</p>
    <a href="https://amzn.to/3O73kv3" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow">Shop Pet Safety Lights →</a>
  </div>
  <div class="section">
    <div class="container">
      <div class="stat-grid">
        <div class="stat-card"><div class="stat-num">300ft</div><div class="stat-label">Driver visibility range</div></div>
        <div class="stat-card"><div class="stat-num">100hr</div><div class="stat-label">Battery life</div></div>
        <div class="stat-card"><div class="stat-num">5sec</div><div class="stat-label">To clip onto collar</div></div>
        <div class="stat-card"><div class="stat-num">3</div><div class="stat-label">Flash modes</div></div>
      </div>
      <div style="text-align:center;margin-top:40px">
        <a href="https://amzn.to/3O73kv3" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow">Shop on Amazon →</a>
      </div>
    </div>
  </div>
</div>

<!-- CYCLISTS PAGE -->
<div id="page-cyclists" class="page">
  <div class="hero">
    <div class="badge badge-yellow">🚴 For Cyclists</div>
    <h1>360° Visibility<br/><span class="accent">for Cyclists.</span></h1>
    <p class="subtitle">Most bike lights only cover the front. Add LED clips to your helmet, bag, and ankles for full all-around visibility at night.</p>
    <a href="https://amzn.to/3O73kv3" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow">Shop Cycling Lights →</a>
  </div>
  <div class="section">
    <div class="container">
      <div class="grid-3">
        <div class="card" style="padding:24px">
          <p class="card-title">⛑️ Helmet</p>
          <p class="card-text">Clip to the top or back strap. Makes your head movement visible to drivers approaching from behind.</p>
        </div>
        <div class="card" style="padding:24px">
          <p class="card-title">🎒 Backpack</p>
          <p class="card-text">Clip to shoulder straps. Great rear visibility without weighing down your bag.</p>
        </div>
        <div class="card" style="padding:24px">
          <p class="card-title">👟 Ankle</p>
          <p class="card-text">The rotating motion of your pedaling creates a distinctive blink pattern that drivers recognize instantly.</p>
        </div>
      </div>
      <div style="text-align:center;margin-top:40px">
        <a href="https://amzn.to/3O73kv3" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-yellow">Get Yours on Amazon →</a>
      </div>
    </div>
  </div>
</div>

<!-- ABOUT PAGE -->
<div id="page-about" class="page">
  <div class="hero">
    <div class="badge badge-yellow">About SimplyLED Store</div>
    <h1>We Help You <span class="accent">Stay Safe</span><br/>After Dark.</h1>
    <p class="subtitle">Honest, unbiased reviews of the best LED clip-on safety lights. No fluff — just clear, practical information.</p>
  </div>
  <div class="section">
    <div class="container">
      <div class="grid-3">
        <div class="card" style="padding:24px">
          <div style="font-size:1.5rem;margin-bottom:12px">🔍</div>
          <p class="card-title">Honest Reviews</p>
          <p class="card-text">We only recommend products with verified reviews and proven track records on Amazon.</p>
        </div>
        <div class="card" style="padding:24px">
          <div style="font-size:1.5rem;margin-bottom:12px">💛</div>
          <p class="card-title">Community Focused</p>
          <p class="card-text">Built for walkers, runners, cyclists, and pet owners who go outside after dark.</p>
        </div>
        <div class="card" style="padding:24px">
          <div style="font-size:1.5rem;margin-bottom:12px">🎯</div>
          <p class="card-title">Safety First</p>
          <p class="card-text">Every recommendation is made with one goal: keeping you and your family safe at night.</p>
        </div>
      </div>
      <div class="tip-box" style="margin-top:32px">
        <p class="tip-title">📋 Affiliate Disclosure</p>
        <p class="disclosure">As an Amazon Associate I earn from qualifying purchases. Product prices and availability are accurate as of the date/time indicated and are subject to change. All product images are property of Amazon and respective manufacturers.</p>
      </div>
    </div>
  </div>
</div>

</main>

<footer>
  <div class="footer-grid">
    <div>
      <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/1c531f4f3_SLS-LOGO1.png" alt="SimplyLED Store" style="height:36px;margin-bottom:12px"/>
      <p style="font-size:.875rem;color:#6b7280;max-width:260px">Honest reviews and curated picks for the best LED safety lights. Stay visible, stay safe.</p>
    </div>
    <div>
      <p class="footer-title">Quick Links</p>
      <a href="#" class="footer-link" onclick="showPage('home')">Home</a>
      <a href="#" class="footer-link" onclick="showPage('joggers')">Joggers</a>
      <a href="#" class="footer-link" onclick="showPage('pets')">Pets</a>
      <a href="#" class="footer-link" onclick="showPage('cyclists')">Cyclists</a>
      <a href="#" class="footer-link" onclick="showPage('about')">About Us</a>
    </div>
    <div>
      <p class="footer-title">Disclosure</p>
      <p class="disclosure">As an Amazon Associate I earn from qualifying purchases. Product prices and availability are subject to change.</p>
    </div>
  </div>
  <div class="footer-bottom">© ${new Date().getFullYear()} SimplyLED Store — mysimplyledstore.com. All rights reserved.</div>
</footer>

<script>
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
  document.getElementById('page-' + name).classList.add('active');
  document.getElementById('nav-' + name) && document.getElementById('nav-' + name).classList.add('active');
  window.scrollTo(0, 0);
  return false;
}
</script>
</body>
</html>`;
}

export default function Export() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [downloaded, setDownloaded] = useState(false);

  useEffect(() => {
    base44.auth.me()
      .then(u => setUser(u))
      .catch(() => setUser(null))
      .finally(() => setLoading(false));
  }, []);

  const handleDownload = () => {
    const html = buildHTML();
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "simplyledstore-backup.html";
    a.click();
    URL.revokeObjectURL(url);
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 3000);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-yellow-400" />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 text-center px-4">
        <Lock className="w-12 h-12 text-red-400" />
        <h2 className="text-2xl font-bold text-white">Access Denied</h2>
        <p className="text-gray-500">This page is only accessible to admins.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-20">
      <div className="max-w-lg w-full bg-white/[0.03] border border-white/10 rounded-2xl p-8 text-center">
        <div className="w-14 h-14 rounded-full bg-yellow-400/10 border border-yellow-400/20 flex items-center justify-center mx-auto mb-5">
          <Download className="w-7 h-7 text-yellow-400" />
        </div>
        <h1 className="text-2xl font-extrabold text-white mb-2">Site Backup</h1>
        <p className="text-gray-400 text-sm mb-6 leading-relaxed">
          Download a complete self-contained HTML backup of SimplyLED Store. Host it anywhere — GitHub Pages, Netlify, or any web server. No dependencies required.
        </p>

        <div className="bg-black/30 rounded-xl p-4 text-left mb-6 space-y-2">
          <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold mb-3">Includes</p>
          {["Home page with all products", "Joggers, Pets & Cyclists pages", "About Us page", "All affiliate links baked in", "Full navigation & footer", "Responsive design", "All styles inline — zero dependencies"].map(item => (
            <div key={item} className="flex items-center gap-2 text-sm text-gray-300">
              <span className="text-yellow-400 text-xs">✓</span> {item}
            </div>
          ))}
        </div>

        <button
          onClick={handleDownload}
          className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-xl transition-all duration-200"
        >
          {downloaded ? (
            <><CheckCircle className="w-5 h-5" /> Downloaded!</>
          ) : (
            <><Download className="w-5 h-5" /> Download HTML Backup</>
          )}
        </button>

        <p className="text-xs text-gray-600 mt-4">
          Re-download anytime to get the latest version. Hosting on GitHub Pages or Netlify is free.
        </p>
      </div>
    </div>
  );
}