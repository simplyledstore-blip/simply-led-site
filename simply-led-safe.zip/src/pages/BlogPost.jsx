import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Clock, ArrowLeft, Tag } from "lucide-react";

const categoryColors = {
  "Cycling Safety": "bg-blue-400/10 text-blue-400 border-blue-400/20",
  "Night Riding Tips": "bg-yellow-400/10 text-yellow-400 border-yellow-400/20",
  "Product Maintenance": "bg-green-400/10 text-green-400 border-green-400/20",
};

export default function BlogPost() {
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const slug = params.get("slug");
    if (!slug) { setLoading(false); return; }
    base44.entities.BlogPost.filter({ slug, published: true })
      .then(results => {
        const p = results[0] || null;
        setPost(p);
        if (p) {
          const setMeta = (attr, key, content) => {
            let el = document.querySelector(`meta[${attr}="${key}"]`);
            if (!el) { el = document.createElement("meta"); el.setAttribute(attr, key); document.head.appendChild(el); }
            el.setAttribute("content", content);
          };
          document.title = `${p.title} | SimplyLED Store`;
          setMeta("name", "description", p.excerpt);
          setMeta("property", "og:title", p.title);
          setMeta("property", "og:description", p.excerpt);
          setMeta("property", "og:type", "article");
          setMeta("property", "og:url", `https://mysimplyledstore.com/BlogPost?slug=${slug}`);
          if (p.cover_image) setMeta("property", "og:image", p.cover_image);
          setMeta("name", "twitter:card", "summary_large_image");
          setMeta("name", "twitter:title", p.title);
          setMeta("name", "twitter:description", p.excerpt);
          if (p.cover_image) setMeta("name", "twitter:image", p.cover_image);
        }
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500">Loading...</div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-gray-500">
        <p className="mb-4">Article not found.</p>
        <Link to={createPageUrl("Blog")} className="text-yellow-400 hover:underline">← Back to Blog</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Cover Image */}
      {post.cover_image && (
        <div className="w-full h-64 sm:h-80 lg:h-96 overflow-hidden">
          <img src={post.cover_image} alt={post.title} className="w-full h-full object-cover opacity-60" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#0a0a0f]" />
        </div>
      )}

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back link */}
        <Link
          to={createPageUrl("Blog")}
          className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-yellow-400 transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Blog
        </Link>

        <motion.article initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          {/* Meta */}
          <div className="flex flex-wrap items-center gap-3 mb-5">
            <span className={`inline-flex items-center text-xs font-medium px-2.5 py-0.5 rounded-full border ${categoryColors[post.category]}`}>
              {post.category}
            </span>
            {post.reading_time && (
              <span className="flex items-center gap-1 text-xs text-gray-600">
                <Clock className="w-3.5 h-3.5" />
                {post.reading_time} min read
              </span>
            )}
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold text-white leading-tight mb-4">
            {post.title}
          </h1>
          <p className="text-gray-400 text-lg mb-10 leading-relaxed border-b border-white/5 pb-8">
            {post.excerpt}
          </p>

          {/* Content */}
          <div className="prose prose-invert prose-sm sm:prose-base max-w-none
            prose-headings:text-white prose-headings:font-bold
            prose-p:text-gray-400 prose-p:leading-relaxed
            prose-strong:text-white
            prose-a:text-yellow-400 prose-a:no-underline hover:prose-a:underline
            prose-li:text-gray-400
            prose-blockquote:border-yellow-400 prose-blockquote:text-gray-400
            prose-hr:border-white/10">
            <ReactMarkdown>{post.content}</ReactMarkdown>
          </div>
        </motion.article>

        {/* CTA */}
        <div className="mt-14 p-6 rounded-2xl border border-yellow-400/20 bg-yellow-400/5 text-center">
          <p className="text-white font-semibold mb-2">Ready to ride safer?</p>
          <p className="text-gray-400 text-sm mb-4">Check out our top-rated LED safety lights on Amazon.</p>
          <a
            href="https://amzn.to/4sw3tXV"
            target="_blank"
            rel="noopener noreferrer nofollow"
            className="inline-block bg-yellow-400 hover:bg-yellow-300 text-black font-semibold text-sm px-6 py-2.5 rounded-xl transition-colors"
          >
            Shop on Amazon →
          </a>
        </div>
      </div>
    </div>
  );
}