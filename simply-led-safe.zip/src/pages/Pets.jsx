import React from "react";
import { motion } from "framer-motion";
import { Check, ExternalLink, Heart, Dog, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Pets() {
  const benefits = [
    "Clip to collars, harnesses, or leashes in seconds",
    "Lightweight — your pet won't even notice it's there",
    "Waterproof design handles puddles and wet weather",
    "Visible from over 1,000 feet for driver awareness",
    "Multiple colors help identify your pet from a distance",
    "Long battery life — up to 100 hours on one set",
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=1400&q=80"
            alt="Dog walking"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-[#0a0a0f]/80 to-[#0a0a0f]" />
        </div>

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-36 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-400/10 border border-green-400/20 mb-6">
              <Heart className="w-3.5 h-3.5 text-green-400" />
              <span className="text-xs font-medium text-green-400 tracking-wide uppercase">Pet Safety</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight">
              Keep Your Furry<br />
              <span className="text-green-400" style={{ textShadow: "0 0 20px rgba(74,222,128,0.4)" }}>Best Friend Visible</span>
            </h1>
            <p className="mt-6 text-lg text-gray-400 max-w-2xl mx-auto">
              Evening and early morning walks don't have to be risky. LED clip-on lights attach to any collar or harness, keeping your pet safe and seen.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 border-t border-white/5">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-2 lg:order-1"
            >
              <div className="rounded-2xl overflow-hidden border border-white/[0.06]">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/ff13deebe_threedogswithLEDlights.png"
                  alt="Dogs playing"
                  className="w-full h-auto"
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-1 lg:order-2"
            >
              <h2 className="text-3xl font-bold text-white mb-6">
                Why Pet Owners Love LED Clip-On Lights
              </h2>
              <p className="text-gray-400 leading-relaxed mb-8">
                Whether it's a quick bathroom break or a long evening walk, your pet deserves to be seen. These tiny LED lights clip onto any collar or harness and provide bright, reliable visibility that drivers can spot from far away.
              </p>

              <ul className="space-y-3 mb-8">
                {benefits.map((benefit, i) => (
                  <li key={i} className="flex items-start gap-3 text-gray-300">
                    <Check className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                    <span className="text-sm">{benefit}</span>
                  </li>
                ))}
              </ul>

              <a
                href="https://amzn.to/3O73kv3"
                target="_blank"
                rel="noopener noreferrer nofollow"
              >
                <Button className="bg-green-500 hover:bg-green-400 text-white font-semibold py-6 px-8 rounded-xl transition-all duration-300 shadow-lg shadow-green-500/20">
                  View on Amazon
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </a>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { value: "1.2M", label: "Pets injured in road incidents yearly", icon: ShieldCheck },
              { value: "1,000ft", label: "Visibility distance with LED lights", icon: Dog },
              { value: "100hrs", label: "Battery life per set of lights", icon: Heart },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center p-6 rounded-2xl bg-white/[0.02] border border-white/[0.06]"
              >
                <stat.icon className="w-6 h-6 text-green-400 mx-auto mb-3" />
                <p className="text-2xl font-bold text-white">{stat.value}</p>
                <p className="text-xs text-gray-500 mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}