import React from "react";
import HeroSection from "../components/home/HeroSection";
import ProductCard from "../components/home/ProductCard";
import VideoSection from "../components/home/VideoSection";
import UseCaseSection from "../components/home/UseCaseSection";
import CompareSection from "../components/home/CompareSection";
import { motion } from "framer-motion";

const products = [
  {
    title: "BLITZU 4 Pack LED Safety Light",
    image: "https://m.media-amazon.com/images/I/8193jO2xkDL._AC_SX679_.jpg",
    affiliateUrl: "https://amzn.to/3O73kv3",
    reviewText:
      "The BLITZU 4-pack includes batteries pre-installed and extras for replacement. Each light offers 3 modes — steady, fast strobe, and slow flash. Ideal for runners, kids, and anyone walking in low-light areas. The clip-on design attaches in seconds to clothing, bags, or gear.",
    benefits: [
      "4 bright LED lights in one pack",
      "3 light modes: steady, fast strobe, slow flash",
      "Batteries included (with extras) — up to 100 hours",
      "Durable clip-on design fits clothing, bags & gear",
      "Weather-resistant construction",
    ],
  },
  {
    title: "Apace Vision LED Safety Light (2 Pack)",
    image: "https://m.media-amazon.com/images/I/81VolVxnHqL._AC_SX679_.jpg",
    affiliateUrl: "https://a.co/d/0eWNFmQo",
    reviewText:
      "The Apace Vision 2-pack features a strong clip and compact design perfect for dog walkers and stroller parents. Includes bonus items like a reflective band. Works great on bikes, kayaks, and running belts.",
    benefits: [
      "Compact & lightweight — barely noticeable when clipped",
      "Bonus reflective band included in the pack",
      "Versatile use: dogs, bikes, strollers, boats",
      "Reliable strobe and steady modes for all conditions",
      "Secure attachment mechanism",
    ],
  },
  {
    title: "9 Pack LED Safety Light (Multi-Color)",
    image: "https://m.media-amazon.com/images/I/81-Yd4d3vzL._AC_SX679_.jpg",
    affiliateUrl: "https://a.co/d/05drSSZs",
    reviewText:
      "This 9-pack comes in red, blue, and green — perfect for color-coding family members or gear. Lightweight and easy to clip anywhere. Great for group runs, school events, or camping trips.",
    benefits: [
      "9 lights in one pack — ideal for groups",
      "3 colors (red, blue, green) for easy identification",
      "Clip-on design fits clothes, wrists, and bags",
      "Great for families, school groups & camping",
      "High visibility strobe keeps everyone seen",
    ],
  },
];

export default function Home() {
  return (
    <div>
      <HeroSection />

      {/* Products Section */}
      <section id="products" className="py-20 sm:py-28 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-yellow-400/10 border border-yellow-400/20 mb-4">
              <span className="text-xs font-medium text-yellow-400 tracking-wide uppercase">
                Featured Products
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white">
              Popular LED Clip-On Safety Lights
            </h2>
            <p className="mt-3 text-gray-400 max-w-xl mx-auto">
              Practical information about popular LED clip-on safety lights for night visibility.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {products.map((product, index) => (
              <ProductCard key={product.title} product={product} index={index} />
            ))}
          </div>
        </div>
      </section>

      <VideoSection />
      <CompareSection />
      <UseCaseSection />

      {/* Final CTA */}
      <section className="py-20 sm:py-28 border-t border-white/5">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Don't Wait Until It's Too Late
            </h2>
            <p className="text-gray-400 mb-8 max-w-xl mx-auto">
              Over 2,000 pedestrians are injured every week in low-visibility conditions. A simple LED light can make all the difference.
            </p>
            <a
              href="https://amzn.to/3O73kv3"
              target="_blank"
              rel="noopener noreferrer nofollow"
              className="inline-flex items-center gap-2 px-8 py-4 bg-yellow-400 text-black font-semibold rounded-xl hover:bg-yellow-300 glow-btn transition-all duration-300"
            >
              View on Amazon
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
}