import React from "react";
import { motion } from "framer-motion";
import { Zap, Target, Heart, ShieldCheck } from "lucide-react";

export default function AboutUs() {
  return (
    <div>
      {/* Hero */}
      <section className="py-24 sm:py-36">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-yellow-400/10 border border-yellow-400/20 mb-6">
              <Zap className="w-3.5 h-3.5 text-yellow-400" />
              <span className="text-xs font-medium text-yellow-400 tracking-wide uppercase">About Us</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
              We Believe Safety<br />
              <span className="text-yellow-400 glow-text">Shouldn't Be Complicated</span>
            </h1>
            <p className="mt-6 text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed">
              SimplyLED Store provides information about popular LED safety lights to help people make informed decisions. Practical guidance for night visibility safety.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 border-t border-white/5">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              {
                icon: Target,
                title: "Clear Information",
                description: "Product information sourced from Amazon listings and customer feedback. Straightforward presentation without bias.",
              },
              {
                icon: Heart,
                title: "Community Focused",
                description: "Runners, pet owners, cyclists — information presented for people who need LED safety lights.",
              },
              {
                icon: ShieldCheck,
                title: "Safety First",
                description: "Focus on products designed for brightness, durability, and real-world visibility needs.",
              },
            ].map((value, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-8 rounded-2xl bg-white/[0.02] border border-white/[0.06] text-center"
              >
                <div className="w-12 h-12 rounded-xl bg-yellow-400/10 border border-yellow-400/20 flex items-center justify-center mx-auto mb-5">
                  <value.icon className="w-6 h-6 text-yellow-400" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-3">{value.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How We Work */}
      <section className="py-20 border-t border-white/5">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white text-center mb-8">How We Work</h2>
            <div className="prose prose-invert prose-sm mx-auto">
              <div className="space-y-6 text-gray-400 leading-relaxed">
                <p>
                  SimplyLED Store presents information about popular LED safety lights available on Amazon. Product details are gathered from Amazon listings and customer reviews to provide helpful context for potential buyers.
                </p>
                <p>
                  The goal is to save time by presenting key information about LED clip-on safety lights in one convenient location.
                </p>
                <p>
                  <strong className="text-gray-300">Affiliate Disclosure:</strong> SimplyLED Store is a participant in the Amazon Associates Program. When you purchase through links on this site, we may earn a small commission at no additional cost to you. This helps keep the site running.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}