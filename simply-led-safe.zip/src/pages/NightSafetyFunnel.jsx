import React, { useEffect } from "react";
import { motion } from "framer-motion";
import { CheckCircle, Star, ArrowRight } from "lucide-react";

const AMAZON_URL = "https://amzn.to/3O73kv3";

const images = [
  "https://m.media-amazon.com/images/I/8193jO2xkDL._AC_SX679_.jpg",
  "https://m.media-amazon.com/images/I/71z6nSSuIML._AC_SX679_.jpg",
  "https://m.media-amazon.com/images/I/71w4GcECubL._AC_SX679_.jpg",
  "https://m.media-amazon.com/images/I/71GhBxEksML._AC_SX679_.jpg",
  "https://m.media-amazon.com/images/I/71fDnDKEbiL._AC_SX679_.jpg",
];

const bullets = [
  "Clips on any collar in seconds",
  "Waterproof design",
  "100+ hour battery life",
];

const reviews = [
  { name: "Tracy B.", text: "I walk my golden retriever every evening. Since I clipped this on her collar, cars slow way down. It's so bright. Worth every penny." },
  { name: "Mike D.", text: "Bought 3 of these — one for each dog. They clip on instantly and the battery truly does last forever. Highly recommend." },
  { name: "Sandra L.", text: "My vet actually recommended something like this after a close call on our street. This is exactly what she described. Love it." },
];

function AmazonButton() {
  return (
    <a
      href={AMAZON_URL}
      target="_blank"
      rel="noopener noreferrer nofollow"
      className="inline-flex items-center justify-center gap-3 bg-yellow-400 hover:bg-yellow-300 text-black font-extrabold text-xl rounded-2xl px-10 py-5 w-full max-w-md transition-all duration-200 shadow-lg shadow-yellow-400/25 hover:shadow-yellow-400/50"
    >
      👉 View on Amazon
      <ArrowRight className="w-5 h-5" />
    </a>
  );
}

export default function NightSafetyFunnel() {
  useEffect(() => {
    document.title = "This Clip Saved My Dog's Life at Night | SimplyLED Store";
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">

      {/* Minimal header */}
      <div className="flex justify-center py-5 border-b border-white/5">
        <img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/a7e7fb818_SLS-LOGO1.png"
          alt="SimplyLED Store"
          className="h-9"
        />
      </div>

      {/* Hero */}
      <section className="max-w-2xl mx-auto px-4 pt-10 pb-6 text-center">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>

          {/* Stars */}
          <div className="inline-flex items-center gap-1 mb-5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            ))}
            <span className="text-sm text-yellow-400 font-semibold ml-2">3,497 Reviews on Amazon</span>
          </div>

          {/* Headline */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold leading-tight mb-4">
            "This Clip <span className="text-yellow-400">Saved My Dog's Life</span> at Night"
          </h1>

          {/* Sub */}
          <p className="text-gray-300 text-lg sm:text-xl leading-relaxed mb-8">
            Drivers can see your dog from <strong className="text-white">300+ feet away</strong> with this tiny LED safety light.
          </p>

          {/* Hero image */}
          <div className="rounded-2xl overflow-hidden border border-white/10 mb-6 bg-black">
            <img
              src={images[0]}
              alt="BLITZU LED Safety Light"
              className="w-full object-contain max-h-80"
            />
          </div>

          {/* Bullets */}
          <div className="text-left max-w-sm mx-auto mb-8 space-y-3">
            {bullets.map((b, i) => (
              <div key={i} className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-gray-200 text-base font-medium">{b}</span>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="flex flex-col items-center gap-3">
            <AmazonButton />
            <p className="text-xs text-gray-600">Free shipping with Prime · Affiliate disclosure below.</p>
          </div>
        </motion.div>
      </section>

      {/* Image gallery */}
      <section className="max-w-2xl mx-auto px-4 py-10 border-t border-white/5">
        <h2 className="text-xl font-bold text-center mb-6 text-gray-300">See It In Action</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {images.slice(1).map((src, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="rounded-xl overflow-hidden border border-white/10 bg-black aspect-square flex items-center justify-center p-2"
            >
              <img src={src} alt={`BLITZU LED Safety Light view ${i + 2}`} className="w-full h-full object-contain" />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Reviews */}
      <section className="max-w-2xl mx-auto px-4 py-10 border-t border-white/5">
        <h2 className="text-2xl font-bold text-center mb-6">What Dog Owners Are Saying</h2>
        <div className="space-y-4">
          {reviews.map((r, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-white/[0.03] border border-white/[0.07] rounded-2xl p-5"
            >
              <div className="flex gap-0.5 mb-2">
                {[...Array(5)].map((_, j) => <Star key={j} className="w-4 h-4 text-yellow-400 fill-yellow-400" />)}
              </div>
              <p className="text-gray-300 text-sm leading-relaxed mb-2">"{r.text}"</p>
              <p className="text-xs text-gray-600 font-semibold">— {r.name}, verified Amazon buyer</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="max-w-2xl mx-auto px-4 py-12 border-t border-white/5 text-center">
        <h2 className="text-2xl sm:text-3xl font-extrabold mb-3">Don't Risk Another Night Walk Without It</h2>
        <p className="text-gray-400 mb-8">One tiny clip. Instant peace of mind. Your dog deserves to be seen.</p>
        <div className="flex flex-col items-center gap-3">
          <AmazonButton />
          <p className="text-xs text-gray-700 max-w-sm mx-auto">
            As an Amazon Associate I earn from qualifying purchases. Prices subject to change.
          </p>
        </div>
      </section>

    </div>
  );
}