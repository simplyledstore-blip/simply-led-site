import React, { useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Copy, Check, AlertCircle } from "lucide-react";

export default function PinterestVerification() {
  const [copied, setCopied] = useState(false);
  const verificationCode = "d9aa21906153a98466c9cb434db0ea61";

  const handleCopy = () => {
    navigator.clipboard.writeText(verificationCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white py-16 px-4">
      <div className="max-w-3xl mx-auto">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-500/15 border border-red-500/30 mb-4">
            <svg className="w-4 h-4" fill="#E60023" viewBox="0 0 24 24">
              <path d="M12 0a12 12 0 00-4.37 23.17c.18-1.62.35-4.1.07-5.87 0 0-.94-3.94-.94-3.94s-.24-.48-.24-1.18c0-1.11.64-1.94 1.44-1.94.68 0 1 .51 1 1.12 0 .68-.43 1.7-.66 2.64-.19.78.4 1.42 1.18 1.42 1.41 0 2.5-1.49 2.5-3.64 0-1.9-1.37-3.23-3.32-3.23-2.26 0-3.59 1.7-3.59 3.45 0 .68.26 1.42.59 1.81.06.08.07.15.05.23l-.22.9c-.04.14-.12.17-.27.1-1-.46-1.62-1.92-1.62-3.09 0-2.51 1.82-4.81 5.25-4.81 2.76 0 4.9 1.96 4.9 4.58 0 2.73-1.72 4.93-4.11 4.93-.8 0-1.56-.42-1.82-.91l-.5 1.88c-.18.69-.66 1.56-1 2.09A12 12 0 1012 0z"/>
            </svg>
            <span className="text-xs font-semibold text-red-400 uppercase tracking-widest">Pinterest Domain Verification</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold mb-3">
            Verify Your Domain on <span className="text-red-400">Pinterest</span>
          </h1>
          <p className="text-gray-400 text-sm max-w-xl mx-auto">
            Follow these steps to claim mysimplyledstore.com on Pinterest and start tracking your pin analytics.
          </p>
        </motion.div>

        {/* Verification Code */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/5 border border-white/10 rounded-2xl p-6 mb-8"
        >
          <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-yellow-400" />
            Your Verification Code
          </h2>
          <div className="flex items-center gap-3 bg-[#0a0a0f] rounded-xl p-4 border border-white/5">
            <code className="flex-1 text-yellow-400 font-mono text-sm break-all">
              {verificationCode}
            </code>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all bg-white/10 hover:bg-white/20 border border-white/10"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
        </motion.div>

        {/* Method: DNS TXT Record (Recommended) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/5 border border-green-500/30 rounded-2xl p-6 mb-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 className="w-5 h-5 text-green-400" />
            <h2 className="text-lg font-bold text-green-400">Recommended Method: DNS TXT Record</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center text-xs font-bold">1</div>
              <div>
                <h3 className="font-semibold text-white mb-1">Log into Pinterest Business</h3>
                <p className="text-sm text-gray-400">Go to <a href="https://www.pinterest.com/settings/claim" target="_blank" rel="noopener noreferrer" className="text-yellow-400 hover:underline">pinterest.com/settings/claim</a></p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center text-xs font-bold">2</div>
              <div>
                <h3 className="font-semibold text-white mb-1">Enter Your Website</h3>
                <p className="text-sm text-gray-400">Type: <code className="text-yellow-400 bg-black/30 px-1.5 py-0.5 rounded">mysimplyledstore.com</code></p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center text-xs font-bold">3</div>
              <div>
                <h3 className="font-semibold text-white mb-1">Choose "Add a TXT record"</h3>
                <p className="text-sm text-gray-400">Pinterest will show you a TXT record to add</p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center text-xs font-bold">4</div>
              <div>
                <h3 className="font-semibold text-white mb-1">Access Your Domain DNS Settings</h3>
                <p className="text-sm text-gray-400 mb-2">Log into your domain registrar (GoDaddy, Namecheap, Cloudflare, etc.)</p>
                <ul className="text-xs text-gray-500 space-y-1 list-disc list-inside">
                  <li>Find "DNS Management" or "DNS Settings"</li>
                  <li>Look for the section to add new records</li>
                </ul>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center text-xs font-bold">5</div>
              <div>
                <h3 className="font-semibold text-white mb-1">Add the TXT Record</h3>
                <div className="text-sm text-gray-400 space-y-2">
                  <p>Create a new TXT record with these values:</p>
                  <div className="bg-black/30 rounded-lg p-3 space-y-1 text-xs font-mono">
                    <div><span className="text-gray-500">Type:</span> <span className="text-yellow-400">TXT</span></div>
                    <div><span className="text-gray-500">Host/Name:</span> <span className="text-yellow-400">@</span> <span className="text-gray-600">(or leave blank)</span></div>
                    <div><span className="text-gray-500">Value:</span> <span className="text-yellow-400">pinterest-site-verification={verificationCode}</span></div>
                    <div><span className="text-gray-500">TTL:</span> <span className="text-yellow-400">3600</span> <span className="text-gray-600">(or default)</span></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center text-xs font-bold">6</div>
              <div>
                <h3 className="font-semibold text-white mb-1">Wait for DNS Propagation</h3>
                <p className="text-sm text-gray-400">This can take 24-48 hours (usually faster)</p>
              </div>
            </div>

            <div className="flex gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center text-xs font-bold">7</div>
              <div>
                <h3 className="font-semibold text-white mb-1">Return to Pinterest and Verify</h3>
                <p className="text-sm text-gray-400">Click the "Verify" button on Pinterest. Done! ✅</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Alternative Method */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/5 border border-white/10 rounded-2xl p-6"
        >
          <h2 className="text-lg font-bold mb-3">Alternative: Contact Base44 Support</h2>
          <p className="text-sm text-gray-400 mb-3">
            If you prefer to add the meta tag directly to your site's HTML head, contact Base44 support and ask them to add:
          </p>
          <div className="bg-[#0a0a0f] rounded-lg p-4 border border-white/5">
            <code className="text-xs text-green-400 font-mono break-all">
              &lt;meta name="p:domain_verify" content="{verificationCode}"/&gt;
            </code>
          </div>
        </motion.div>

        {/* Footer Note */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center mt-10"
        >
          <p className="text-xs text-gray-600">
            Need help? Check <a href="https://help.pinterest.com/en/business/article/claim-your-website" target="_blank" rel="noopener noreferrer" className="text-yellow-400 hover:underline">Pinterest's official guide</a>
          </p>
        </motion.div>

      </div>
    </div>
  );
}