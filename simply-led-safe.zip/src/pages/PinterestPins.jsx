import React, { useState } from "react";
import { motion } from "framer-motion";
import { Download, Copy, Check, Image as ImageIcon } from "lucide-react";

const DISCLAIMER = "As an Amazon Associate I earn from qualifying purchases.";

const pins = [
  {
    id: 1,
    title: "This Clip Saved My Dog's Life at Night",
    description: "Drivers can see your dog from 300+ feet away with this tiny LED safety light. Clips onto any collar in seconds. Waterproof, 100+ hour battery. Every dog owner needs this.\n\nShop now: mysimplyledstore.com/nightsafety\n\n#dogsafety #petowner #ledlight #nightwalks #petsafety #amazonaffiliate #affiliate",
    board: "Pet Safety Essentials",
    hook: "Emotional + Benefit",
    imageUrl: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/412f4efef_generated_image.png",
    imagePrompt: "A golden retriever wearing a bright LED clip-on light on its collar at dusk, walking safely on a suburban sidewalk with a car's headlights visible in the background. The LED light glows bright yellow-green. Warm, safe feeling. Vertical Pinterest format 1000x1500px. Text overlay at top: 'This Clip Saved My Dog's Life' in bold white text with dark shadow."
  },
  {
    id: 2,
    title: "Drivers Can't See You at Night — Until Now",
    description: "6,000+ pedestrians are killed each year in low-light accidents. This LED clip-on light makes you visible from over 300 feet away. Lightweight, weatherproof, and lasts 100+ hours on one battery.\n\nmysimplyledstore.com/nightsafety\n\n#nightsafety #walkingsafety #ledlight #visibility #safetyfirst #amazonaffiliate #affiliate",
    board: "Night Safety Tips",
    hook: "Fear + Solution",
    imageUrl: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/9f7579f6c_generated_image.png",
    imagePrompt: "A person jogging at night on a dark road wearing multiple bright LED clip-on lights on their jacket and backpack, visible from far away. Headlights approaching in the distance. Dark blue night sky, urban setting. Vertical Pinterest format 1000x1500px. Bold text overlay: 'Drivers Can't See You at Night — Until Now' in yellow and white."
  },
  {
    id: 3,
    title: "360° Visibility for Cyclists",
    description: "Most bike lights only light the front. Clip these LED lights to your helmet, bag, and ankle for full 360° visibility. Every cyclist needs this.\n\nSee our top picks: mysimplyledstore.com/nightsafety\n\n#cycling #bikesafety #nightcycling #ledlight #cyclistsafety #amazonaffiliate #affiliate",
    board: "Cycling Safety & Gear",
    hook: "Problem + Affordable Solution",
    imageUrl: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/69f339dd2_generated_image.png",
    imagePrompt: "A cyclist riding at night with LED clip-on lights attached to helmet, backpack straps, and ankles, creating a 360-degree glow effect. City street at dusk, bike lane visible. Dynamic action shot. Vertical Pinterest format 1000x1500px. Text overlay: '360° Visibility for Cyclists' in bold white text with dark shadow."
  },
  {
    id: 4,
    title: "The One Safety Item Every Runner Needs",
    description: "You run early morning or late evening? This LED clip-on light could save your life. Clips to your shirt, hat, or armband. Ultra-bright, 3 flash modes, lasts 100+ hours.\n\nmysimplyledstore.com/nightsafety\n\n#running #runnersafety #nightrunning #ledlight #marathontraining #amazonaffiliate #affiliate",
    board: "Running & Jogging Safety",
    hook: "Authority + Urgency",
    imageUrl: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/d58c8238a_generated_image.png",
    imagePrompt: "A female runner in athletic gear running on a trail at dawn with LED clip-on lights on her shoulders and waist, glowing bright yellow. Misty morning atmosphere, forest trail background. Energetic and safe feeling. Vertical Pinterest format 1000x1500px. Text: 'The One Safety Item Every Runner Needs' in bold modern font."
  },
  {
    id: 5,
    title: "How to Keep Your Kids Visible on Their Way to School",
    description: "Parents — this simple clip makes your child visible from over 300 feet away. Clips onto backpacks, jackets, or lunch boxes. Weatherproof and lasts all year on one battery.\n\nmysimplyledstore.com/nightsafety\n\n#parenting #kidsafety #schoolsafety #ledlight #backtoschool #amazonaffiliate #affiliate",
    board: "Parenting & Kids Safety",
    hook: "Parent Fear + Peace of Mind",
    imageUrl: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/4c0a3dddb_generated_image.png",
    imagePrompt: "A child with a backpack walking to school in early morning light, with a bright LED clip-on light attached to the backpack strap, glowing visibly. Safe suburban street, school bus in background. Warm, protective feeling. Vertical Pinterest format 1000x1500px. Text: 'Keep Your Kids Visible on Their Way to School' in friendly, bold font."
  },
  {
    id: 6,
    title: "Before & After: See the Difference LED Lights Make",
    description: "Left: Invisible in the dark. Right: Visible from 300+ feet. This tiny LED clip could be the difference between safe and sorry. Lightweight, lasts 100+ hours.\n\nmysimplyledstore.com/nightsafety\n\n#beforeandafter #nightsafety #ledlight #safetygear #visibility #amazonaffiliate #affiliate",
    board: "Night Safety Tips",
    hook: "Visual Proof",
    imageUrl: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/8fd47f8af_generated_image.png",
    imagePrompt: "Split-screen comparison image. Left side: person barely visible in darkness on a road. Right side: same person highly visible with bright LED clip-on lights glowing yellow-green. Dark road setting, dramatic contrast. Vertical Pinterest format 1000x1500px. Bold text: 'Before & After: See the Difference' with arrows pointing to the lights."
  }
];

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
      style={{
        background: copied ? "rgba(74,222,128,0.15)" : "rgba(255,255,255,0.08)",
        color: copied ? "#4ade80" : "#aaa",
        border: `1px solid ${copied ? "rgba(74,222,128,0.3)" : "rgba(255,255,255,0.1)"}`,
      }}
    >
      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? "Copied!" : "Copy"}
    </button>
  );
}

export default function PinterestPins() {
  const [generatingId, setGeneratingId] = useState(null);

  const handleDownload = async (pin) => {
    const response = await fetch(pin.imageUrl);
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pin-${pin.id}.png`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleGenerateImage = async (pin) => {
    setGeneratingId(pin.id);
    // In production, this would call your image generation API
    // For now, we'll simulate the process
    await new Promise(resolve => setTimeout(resolve, 2000));
    setGeneratingId(null);
    alert(`Image generated! In production, this would generate the pin image and allow you to download it.`);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pb-20">
      {/* Header */}
      <div className="max-w-5xl mx-auto px-4 pt-10 pb-6">
        <motion.div initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <span className="inline-block px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold uppercase tracking-widest mb-4">
            High-Conversion Pinterest Pins
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold mb-3">
            Ready-to-Use <span className="text-yellow-400">Pinterest Pin Templates</span>
          </h1>
          <p className="text-gray-400 text-sm max-w-2xl mx-auto">
            Copy the title and description, generate the AI image, and upload directly to your Pinterest boards. Each pin is optimized for maximum engagement and click-through rates.
          </p>
        </motion.div>
      </div>

      {/* Pin Grid */}
      <div className="max-w-5xl mx-auto px-4 space-y-6">
        {pins.map((pin, idx) => (
          <motion.div
            key={pin.id}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="rounded-2xl border bg-white/[0.03] p-6"
            style={{ borderColor: "rgba(255,255,255,0.08)" }}
          >
            <div className="flex flex-col lg:flex-row gap-6">
              {/* Image Preview */}
              <div className="lg:w-64 flex-shrink-0">
                <div className="aspect-[2/3] rounded-xl overflow-hidden bg-gray-900 border border-yellow-400/20 relative group">
                  <img 
                    src={pin.imageUrl} 
                    alt={pin.title}
                    className="w-full h-full object-cover"
                  />
                  <button
                    onClick={() => handleDownload(pin)}
                    className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center w-full border-0 cursor-pointer"
                  >
                    <div className="text-center">
                      <Download className="w-8 h-8 text-white mx-auto mb-2" />
                      <span className="text-white text-sm font-semibold">Download Pin</span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 space-y-4">
                {/* Meta Info */}
                <div className="flex flex-wrap gap-2">
                  <span className="px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-semibold">
                    {pin.board}
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-semibold">
                    {pin.hook}
                  </span>
                </div>

                {/* Title */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Pin Title</label>
                    <CopyButton text={pin.title} />
                  </div>
                  <p className="text-lg font-bold text-white">{pin.title}</p>
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Pin Description</label>
                    <CopyButton text={pin.description + "\n\n" + DISCLAIMER} />
                  </div>
                  <pre className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed font-sans bg-white/[0.02] rounded-lg p-4 border border-white/5">
                    {pin.description}
                    {"\n\n"}
                    <span className="text-gray-600 text-xs">{DISCLAIMER}</span>
                  </pre>
                </div>

                {/* Image Prompt (for reference) */}
                <details className="text-xs">
                  <summary className="text-gray-500 cursor-pointer hover:text-gray-400 transition-colors">
                    View AI Image Prompt
                  </summary>
                  <p className="mt-2 text-gray-600 leading-relaxed bg-white/[0.02] rounded p-3 border border-white/5">
                    {pin.imagePrompt}
                  </p>
                </details>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Tips */}
      <div className="max-w-5xl mx-auto px-4 mt-12">
        <div className="rounded-2xl border border-yellow-400/20 bg-yellow-400/5 p-6">
          <h3 className="text-yellow-400 font-bold text-sm uppercase tracking-wider mb-3">📌 Pinterest Best Practices</h3>
          <ul className="text-sm text-gray-400 space-y-2 list-disc list-inside">
            <li>Pin images work best in vertical format (1000x1500px or 2:3 ratio)</li>
            <li>Use bold, readable text overlays with high contrast</li>
            <li>Post consistently — aim for 5-10 pins per day for best reach</li>
            <li>Always include a clear call-to-action and your website link</li>
            <li>Use all 500 characters in your description for better SEO</li>
            <li>Add relevant hashtags (3-5 per pin is optimal)</li>
            <li>The Amazon affiliate disclaimer is legally required</li>
          </ul>
        </div>
      </div>
    </div>
  );
}