import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Clock, Tag } from "lucide-react";

const categoryColors = {
  "Cycling Safety": "bg-blue-400/10 text-blue-400 border-blue-400/20",
  "Night Riding Tips": "bg-yellow-400/10 text-yellow-400 border-yellow-400/20",
  "Product Maintenance": "bg-green-400/10 text-green-400 border-green-400/20",
};

export default function Blog() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState("All");

  const categories = ["All", "Cycling Safety", "Night Riding Tips", "Product Maintenance"];

  useEffect(() => {
    base44.entities.BlogPost.filter({ published: true }, "-created_date")
      .then(setPosts)
      .finally(() => setLoading(false));
  }, []);

  const filtered = activeCategory === "All"
    ? posts
    : posts.filter(p => p.category === activeCategory);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="py-20 sm:py-28 text-center border-b border-white/5">
        <div className="max-w-3xl mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-yellow-400/10 border border-yellow-400/20 mb-6">
              <Tag className="w-3.5 h-3.5 text-yellow-400" />
              <span className="text-xs font-medium text-yellow-400 tracking-wide uppercase">Safety Blog</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
              Tips, Guides & Reviews
            </h1>
            <p className="text-gray-400 text-lg">
              Expert advice on cycling safety, night riding, and keeping your gear in top condition.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter Tabs */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-wrap gap-2 mb-10">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-all ${
                activeCategory === cat
                  ? "bg-yellow-400/10 text-yellow-400 border-yellow-400/30"
                  : "text-gray-400 border-white/10 hover:border-white/20 hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Posts Grid */}
        {loading ? (
          <div className="text-center py-20 text-gray-500">Loading articles...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 text-gray-500">No articles yet. Check back soon!</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((post, i) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
              >
                <Link
                  to={createPageUrl(`BlogPost?slug=${post.slug}`)}
                  className="block h-full rounded-2xl border border-white/[0.06] bg-white/[0.02] hover:border-yellow-400/20 hover:bg-white/[0.04] transition-all overflow-hidden group"
                >
                  {post.cover_image && (
                    <div className="aspect-video overflow-hidden">
                      <img
                        src={post.cover_image}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  )}
                  <div className="p-5">
                    <span className={`inline-flex items-center text-xs font-medium px-2.5 py-0.5 rounded-full border mb-3 ${categoryColors[post.category]}`}>
                      {post.category}
                    </span>
                    <h2 className="text-white font-semibold text-lg leading-snug mb-2 group-hover:text-yellow-400 transition-colors">
                      {post.title}
                    </h2>
                    <p className="text-gray-500 text-sm leading-relaxed line-clamp-3 mb-4">{post.excerpt}</p>
                    {post.reading_time && (
                      <div className="flex items-center gap-1.5 text-xs text-gray-600">
                        <Clock className="w-3.5 h-3.5" />
                        {post.reading_time} min read
                      </div>
                    )}
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}