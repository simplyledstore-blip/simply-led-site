import React, { useEffect } from "react";

export default function NightSafety() {
  useEffect(() => {
    window.location.href = "https://amzn.to/4sw3tXV";
  }, []);

  return (
    <div className="fixed inset-0 bg-[#0a0a0f] flex flex-col items-center justify-center z-50">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin mx-auto mb-6" />
        <p className="text-white text-lg font-medium mb-4">Redirecting to our Amazon product page...</p>
        <a href="https://amzn.to/4sw3tXV" className="text-yellow-400 underline text-sm">Click here if not redirected automatically</a>
      </div>
    </div>
  );
}