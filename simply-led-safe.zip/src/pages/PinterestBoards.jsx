import React, { useState } from "react";
import { motion } from "framer-motion";
import { Copy, Check, Pin, Lightbulb } from "lucide-react";

const boards = [
  {
    name: "Night Safety Tips & LED Lights",
    description: "Essential safety tips and the best LED clip-on lights for staying visible during evening walks, runs, and outdoor activities. #NightSafety #LEDLights #VisibilityGear",
    color: "#E60023",
    pins: [
      {
        title: "5 Night Walking Safety Tips Everyone Should Know",
        description: "Stay safe during evening walks with these essential visibility tips. LED clip-on lights make you visible from 300+ feet away. #NightSafety #WalkingSafety\n\nShop LED lights → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Infographic with 5 safety tips"
      },
      {
        title: "Why You Need an LED Safety Light for Night Walks",
        description: "Over 6,000 pedestrians are killed in traffic accidents yearly. Many happen in low-light conditions. A simple LED light could save your life. #SafetyFirst\n\nBest LED lights → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Before/after visibility comparison"
      },
      {
        title: "The Best LED Clip-On Lights for Night Visibility",
        description: "100+ hour battery, weatherproof, 3 light modes. These LED safety lights are affordable and could save your life. #LEDLights #AmazonFinds\n\nShop now → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Product showcase image"
      }
    ]
  },
  {
    name: "Best LED Lights for Runners & Joggers",
    description: "Top-rated LED safety lights and visibility gear for runners who train early morning or evening. Stay safe and be seen. #RunningGear #NightRunning #RunnerSafety",
    color: "#0084FF",
    pins: [
      {
        title: "Essential Night Running Safety Gear for Joggers",
        description: "Don't let darkness stop your training. These LED clip-on lights attach to your clothing, shoes, or hat for 360° visibility. #NightRunning #RunningGear\n\nTop picks → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Runner wearing LED lights"
      },
      {
        title: "How to Stay Visible During Early Morning Runs",
        description: "Morning runners need maximum visibility. These lightweight LED lights won't weigh you down but will keep you safe. #RunningSafety\n\nShop LEDs → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Dawn running scene with visibility tips"
      },
      {
        title: "Affordable LED Safety Lights Every Runner Needs",
        description: "Clip-on design, long battery life, multiple flash modes. Perfect for joggers who run before sunrise or after sunset. #RunningEssentials\n\nFind them here → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Product features collage"
      }
    ]
  },
  {
    name: "Dog Safety: LED Collar Lights",
    description: "Keep your furry friend safe during evening walks with LED collar lights and pet safety gear. Perfect for dog owners who walk at dusk or dawn. #DogSafety #PetSafety #DogWalking",
    color: "#FFBA08",
    pins: [
      {
        title: "Best LED Collar Lights for Dogs Who Walk at Night",
        description: "Your dog deserves to be seen! These LED lights clip onto any collar or leash. Drivers can see them from 300+ feet away. #DogSafety #PetOwner\n\nShop now → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Dog wearing LED collar light"
      },
      {
        title: "Why Every Dog Owner Needs an LED Safety Light",
        description: "Evening dog walks are safer with proper visibility. These weatherproof LED lights take 5 seconds to clip on. #DogMom #DogDad\n\nGet yours → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Happy dog on evening walk"
      },
      {
        title: "Affordable Pet Safety Lights for Night Walks",
        description: "Lightweight, bright, and durable. Perfect for dogs who love walks at any hour. Your pup will thank you! #PetSafety\n\nCheck it out → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Multiple dogs with different colored lights"
      }
    ]
  },
  {
    name: "Cycling Safety Gear & LED Lights",
    description: "Essential LED safety lights and visibility gear for cyclists who ride at dawn, dusk, or night. Ride safe, be seen. #CyclingSafety #BikeLife #NightCycling",
    color: "#00C853",
    pins: [
      {
        title: "Best LED Clip-On Lights for Night Cyclists",
        description: "Most bike lights only cover the front. Add these LED clips to your helmet, backpack, or ankles for full 360° visibility. #CyclistSafety\n\nShop lights → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Cyclist with multiple LED lights"
      },
      {
        title: "How to Stay Visible While Cycling at Night",
        description: "Supplement your bike lights with clip-on LEDs for maximum visibility from all angles. Simple and effective. #BikeLife\n\nFind them → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Bike safety diagram showing light placement"
      },
      {
        title: "Affordable Cycling Safety Lights That Actually Work",
        description: "Bright, durable, and weatherproof. Perfect for commuters and recreational cyclists. Don't ride in the dark without these. #SafeCycling\n\nGet yours → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Product showcase with cyclist testimonial"
      }
    ]
  },
  {
    name: "Amazon Safety Finds Under $20",
    description: "Affordable safety products and LED lights from Amazon that don't break the bank. Smart safety solutions for everyday life. #AmazonFinds #SafetyGear #BudgetFriendly",
    color: "#FF6F00",
    pins: [
      {
        title: "Top Affordable Safety Products on Amazon",
        description: "You don't need to spend a fortune to stay safe. These LED safety lights are affordable and highly rated. #AmazonFinds\n\nShop deals → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Price comparison graphic"
      },
      {
        title: "Best Budget LED Safety Lights for Families",
        description: "Get the whole family equipped without breaking the bank. Multi-packs available for walkers, runners, cyclists, and pets. #FamilySafety\n\nSee options → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Family using LED lights together"
      },
      {
        title: "Amazon Must-Have: LED Safety Clip-On Lights",
        description: "Thousands of 5-star reviews. Affordable, reliable, and potentially life-saving. A smart purchase for anyone who goes outside after dark. #MusthaveAmazonProducts\n\nCheck them out → mysimplyledstore.com/nightsafety\n\n#ad #amazonaffiliate — As an Amazon Associate I earn from qualifying purchases.",
        imageIdea: "Amazon review highlights"
      }
    ]
  }
];

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all bg-white/10 hover:bg-white/20 border border-white/10"
    >
      {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? "Copied!" : "Copy"}
    </button>
  );
}

export default function PinterestBoards() {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white py-16 px-4">
      <div className="max-w-5xl mx-auto">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-500/15 border border-red-500/30 mb-4">
            <Pin className="w-4 h-4 text-red-400" />
            <span className="text-xs font-semibold text-red-400 uppercase tracking-widest">Pinterest Strategy</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold mb-3">
            Your 5 Pinterest <span className="text-red-400">Boards</span>
          </h1>
          <p className="text-gray-400 text-sm max-w-2xl mx-auto">
            Create these boards on Pinterest, then use the pin templates below to populate them with content. All descriptions and pins are ready to copy and paste.
          </p>
        </motion.div>

        {/* Quick Setup Guide */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-yellow-400/10 border border-yellow-400/30 rounded-2xl p-6 mb-10"
        >
          <div className="flex items-start gap-3">
            <Lightbulb className="w-5 h-5 text-yellow-400 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-bold text-yellow-400 mb-2">How to Use This Guide</h3>
              <ol className="text-sm text-gray-300 space-y-1.5 list-decimal list-inside">
                <li>Go to Pinterest and create each board using the names below</li>
                <li>Copy the board description and paste it into Pinterest</li>
                <li>Create pins using the templates provided (3 pins per board to start)</li>
                <li>Use product images or create graphics with Canva for each pin</li>
                <li>Post consistently — aim for 2-3 pins per day across all boards</li>
              </ol>
            </div>
          </div>
        </motion.div>

        {/* Boards */}
        <div className="space-y-8">
          {boards.map((board, bi) => (
            <motion.div
              key={board.name}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: bi * 0.1 }}
              className="bg-white/5 border border-white/10 rounded-2xl p-6"
            >
              {/* Board Header */}
              <div className="flex items-start justify-between mb-4 pb-4 border-b border-white/10">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: board.color }}></div>
                    <h2 className="text-xl font-bold">{board.name}</h2>
                  </div>
                  <p className="text-sm text-gray-400">{board.description}</p>
                </div>
                <CopyButton text={board.description} />
              </div>

              {/* Pins */}
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Pin Templates ({board.pins.length})</h3>
                {board.pins.map((pin, pi) => (
                  <div key={pi} className="bg-black/30 border border-white/5 rounded-xl p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-semibold text-white mb-1">{pin.title}</h4>
                        <p className="text-xs text-gray-500 italic">💡 Image idea: {pin.imageIdea}</p>
                      </div>
                      <CopyButton text={`${pin.title}\n\n${pin.description}`} />
                    </div>
                    <pre className="text-xs text-gray-300 whitespace-pre-wrap leading-relaxed font-sans bg-[#0a0a0f] rounded-lg p-3 border border-white/5">
                      {pin.description}
                    </pre>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Footer Tips */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-12 bg-white/5 border border-white/10 rounded-2xl p-6"
        >
          <h3 className="font-bold mb-3 flex items-center gap-2">
            <Pin className="w-4 h-4 text-red-400" />
            Pinterest Best Practices
          </h3>
          <ul className="text-sm text-gray-400 space-y-2 list-disc list-inside">
            <li>Create vertical images (1000x1500px recommended) using Canva or product photos</li>
            <li>Use high-quality, eye-catching images that stand out in the feed</li>
            <li>Include text overlays on images with key benefits (e.g., "Stay Safe at Night")</li>
            <li>Pin consistently — schedule pins in advance using Pinterest's scheduler</li>
            <li>Engage with other users' pins in your niche (like, comment, repin)</li>
            <li>Add relevant keywords to pin titles and descriptions for SEO</li>
            <li>All pins link to: <code className="text-yellow-400 bg-black/30 px-1.5 py-0.5 rounded">mysimplyledstore.com/nightsafety</code></li>
          </ul>
        </motion.div>

      </div>
    </div>
  );
}