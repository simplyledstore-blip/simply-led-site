import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Shield, Zap, Star, AlertTriangle, ChevronRight, Clock } from "lucide-react";

const PRODUCT_URL = "https://mysimplyledstore.com/nightsafety";

export default function Promo() {
  const [timeLeft, setTimeLeft] = useState({ hours: 23, minutes: 59, seconds: 59 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { hours, minutes, seconds } = prev;
        if (seconds > 0) return { hours, minutes, seconds: seconds - 1 };
        if (minutes > 0) return { hours, minutes: minutes - 1, seconds: 59 };
        if (hours > 0) return { hours: hours - 1, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const pad = (n) => String(n).padStart(2, "0");

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex flex-col items-center">

      {/* Urgency Banner */}
      <div className="w-full bg-yellow-400 text-black text-center py-2 px-4 text-sm font-bold tracking-wide flex items-center justify-center gap-2">
        <Clock className="w-4 h-4" />
        LIMITED TIME — Deal ends in: {pad(timeLeft.hours)}:{pad(timeLeft.minutes)}:{pad(timeLeft.seconds)}
      </div>

      {/* Hero */}
      <section className="w-full max-w-3xl mx-auto px-6 pt-16 pb-10 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-500/15 border border-red-500/30 mb-5">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span className="text-xs font-semibold text-red-400 uppercase tracking-widest">Don't Walk in the Dark Unprotected</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-extrabold leading-tight mb-4">
            Be Seen. <span className="text-yellow-400">Stay Safe.</span><br />Every Single Night.
          </h1>

          <p className="text-gray-400 text-lg mb-8 max-w-xl mx-auto">
            Over <strong className="text-white">2,000 pedestrians</strong> are hit every week in low-visibility conditions.
            A simple LED safety clip-on light could save your life — or someone you love.
          </p>

          {/* Product Image */}
          <div className="relative rounded-2xl overflow-hidden mb-8 border border-white/10 shadow-2xl">
            <img
              src="https://m.media-amazon.com/images/I/8193jO2xkDL._AC_SX679_.jpg"
              alt="LED Safety Light"
              className="w-full max-h-72 object-contain bg-[#111118] p-6"
            />
            <div className="absolute top-4 right-4 bg-yellow-400 text-black text-xs font-bold px-3 py-1 rounded-full">
              #1 BESTSELLER
            </div>
          </div>

          {/* Stars */}
          <div className="flex items-center justify-center gap-1 mb-2">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
            ))}
            <span className="ml-2 text-gray-400 text-sm">4.8 / 5 — 3,400+ reviews</span>
          </div>
        </motion.div>
      </section>

      {/* Benefits */}
      <section className="w-full max-w-3xl mx-auto px-6 pb-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-4"
        >
          {[
            { icon: Zap, title: "100+ Hour Battery", desc: "Runs all season on one set of batteries" },
            { icon: Shield, title: "Weather Resistant", desc: "Works in rain, fog, and cold nights" },
            { icon: Star, title: "3 Light Modes", desc: "Steady, fast strobe & slow flash" },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="bg-white/5 border border-white/10 rounded-xl p-5 text-center">
              <Icon className="w-7 h-7 text-yellow-400 mx-auto mb-3" />
              <h3 className="font-semibold text-white mb-1">{title}</h3>
              <p className="text-sm text-gray-400">{desc}</p>
            </div>
          ))}
        </motion.div>
      </section>

      {/* Social Proof */}
      <section className="w-full max-w-3xl mx-auto px-6 pb-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="space-y-4"
        >
          {[
            { name: "Sarah M.", text: "My whole family clips these on every evening walk. So bright — cars see us from far away!" },
            { name: "James R.", text: "Got the 4-pack, gave one to each of my kids. Best $10 I've ever spent on safety." },
            { name: "Laura T.", text: "My dog wears one on his collar. Game changer for early morning walks." },
          ].map(({ name, text }) => (
            <div key={name} className="bg-white/5 border border-white/10 rounded-xl p-4 flex gap-3">
              <div className="w-8 h-8 rounded-full bg-yellow-400/20 text-yellow-400 font-bold flex items-center justify-center shrink-0 text-sm">
                {name[0]}
              </div>
              <div>
                <p className="text-sm text-gray-300">"{text}"</p>
                <p className="text-xs text-gray-500 mt-1">— {name}, verified buyer</p>
              </div>
            </div>
          ))}
        </motion.div>
      </section>

      {/* CTA */}
      <section className="w-full max-w-3xl mx-auto px-6 pb-16 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          <a
            href={PRODUCT_URL}
            target="_blank"
            rel="noopener noreferrer nofollow"
            className="inline-flex items-center gap-3 px-10 py-5 bg-yellow-400 text-black font-extrabold text-lg rounded-2xl hover:bg-yellow-300 transition-all duration-300 w-full sm:w-auto justify-center"
            style={{ boxShadow: "0 0 30px rgba(250,204,21,0.3)" }}
          >
            Get My Safety Light Now
            <ChevronRight className="w-5 h-5" />
          </a>
          <p className="text-gray-500 text-xs mt-4">
            Ships via Amazon · Free returns · As an Amazon Associate we earn from qualifying purchases.
          </p>
        </motion.div>
      </section>

    </div>
  );
}