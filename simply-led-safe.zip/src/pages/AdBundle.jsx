import React, { useState } from "react";
import { motion } from "framer-motion";
import { Copy, Check, Instagram, Facebook } from "lucide-react";

const DISCLAIMER = "#ad #amazonaffiliate #amazonassociate — As an Amazon Associate I earn from qualifying purchases.";

const ads = [
  {
    platform: "TikTok",
    category: "Safety / Awareness",
    color: "#ffffff",
    bg: "rgba(255,255,255,0.07)",
    border: "rgba(255,255,255,0.18)",
    icon: (
      <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
        <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.16 8.16 0 004.77 1.53V6.77a4.85 4.85 0 01-1-.08z"/>
      </svg>
    ),
    posts: [
      {
        label: "Hook Post",
        text: `POV: You go for an evening walk and a car almost doesn't see you 😨\n\nThis LED clip-on light changed everything for my family. Clips onto any jacket, bag, or collar — 100+ hour battery, 3 flash modes, weatherproof.\n\nLink in bio 👉 mysimplyledstore.com/nightsafety\n\n#nightsafety #ledlight #safetyfirst #walkingsafety #nightwalking #visibilitygear ${DISCLAIMER}`
      },
      {
        label: "Pet Safety Post",
        text: `Your dog deserves to be seen at night 🐾✨\n\nThis tiny LED light clips right onto their collar or leash. Drivers see them from 300+ feet away. It takes 5 seconds to clip on.\n\nLink in bio 👉 mysimplyledstore.com/nightsafety\n\n#dogsafety #petowner #nightwalks #dogmom #dogdad #petsafety #ledlight ${DISCLAIMER}`
      },
      {
        label: "Cyclist Post",
        text: `Cyclists — this might save your life 🚴‍♂️⚡\n\nMost bike lights only light the front. Clip these LED lights to your helmet, bag strap, or ankle for full 360° visibility at night.\n\nLink in bio 👉 mysimplyledstore.com/nightsafety\n\n#cycling #cyclistsafety #nightcycling #bikelife #safecycling #ledlight ${DISCLAIMER}`
      },
    ]
  },
  {
    platform: "Instagram",
    category: "Reels & Feed",
    color: "#E1306C",
    bg: "rgba(225,48,108,0.08)",
    border: "rgba(225,48,108,0.25)",
    icon: <Instagram className="w-5 h-5" />,
    posts: [
      {
        label: "Lifestyle Post",
        text: `Night walks are one of life's simple joys — don't let poor visibility ruin them 🌙\n\nWe found the best LED safety clip-on lights on Amazon. Bright, lightweight, and affordable. Perfect for walkers, runners, cyclists, and pets.\n\n🔗 Link in bio → mysimplyledstore.com/nightsafety\n\n#nightwalk #ledlights #safetyfirst #walkingatnight #stavisible #nightrunning #amazonfinds ${DISCLAIMER}`
      },
      {
        label: "Product Feature",
        text: `Simple. Affordable. Could save your life. 💛\n\n✅ 100+ hour battery life\n✅ 3 light modes (steady, fast flash, slow flash)\n✅ Weather resistant\n✅ Clips to anything — jacket, bag, collar, helmet\n✅ Affordable on Amazon\n\nShop now → link in bio 🔗\n\n#amazonfinds #ledlight #safetygear #nightsafety #visibilitygear #musthave ${DISCLAIMER}`
      },
      {
        label: "Story / Reel Caption",
        text: `Swipe up to see the #1 LED safety light we recommend for night walkers, runners, cyclists & pet owners 🔦\n\nStay visible. Stay safe.\n👉 mysimplyledstore.com/nightsafety\n\n#nightsafety #ledcliplight #amazonfinds #stavisible ${DISCLAIMER}`
      },
    ]
  },
  {
    platform: "Facebook",
    category: "Posts & Groups",
    color: "#1877F2",
    bg: "rgba(24,119,242,0.08)",
    border: "rgba(24,119,242,0.25)",
    icon: <Facebook className="w-5 h-5" />,
    posts: [
      {
        label: "Community Safety Post",
        text: `🚨 If you or your family walk, jog, or cycle after dark — please read this.\n\nOver 6,000 pedestrians are killed in traffic accidents in the US every year. Many happen in low-light conditions where drivers simply didn't see them in time.\n\nA simple LED clip-on safety light can make you visible from over 300 feet away. We've rounded up the best ones on Amazon so you don't have to guess.\n\n👉 Check them out at mysimplyledstore.com/nightsafety\n\nShare this with someone you care about 💛\n\n${DISCLAIMER}`
      },
      {
        label: "Product Recommendation",
        text: `💡 Looking for a gift that could actually save someone's life?\n\nThese LED safety clip-on lights are perfect for:\n🚶 Evening walkers\n🏃 Night runners\n🚴 Cyclists\n🐕 Dog owners\n\nThey clip onto anything, last 100+ hours on one battery, and are completely weatherproof. We only recommend products we've verified have top ratings and reviews on Amazon.\n\nShop our picks → mysimplyledstore.com/nightsafety\n\n${DISCLAIMER}`
      },
      {
        label: "Engagement Post",
        text: `Quick question for our community 👇\n\nDo you wear any kind of visibility gear when walking or running at night?\n\n🟡 Yes — always!\n⚪ Sometimes\n🔴 Never thought about it\n\nNight visibility is something a lot of people overlook until it's too late. We created SimplyLED Store to make finding the right safety light easy and affordable.\n\n👉 See our top picks: mysimplyledstore.com/nightsafety\n\n${DISCLAIMER}`
      },
    ]
  }
];

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
      style={{
        background: copied ? "rgba(74,222,128,0.15)" : "rgba(255,255,255,0.08)",
        color: copied ? "#4ade80" : "#aaa",
        border: `1px solid ${copied ? "rgba(74,222,128,0.3)" : "rgba(255,255,255,0.1)"}`,
      }}
    >
      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? "Copied!" : "Copy"}
    </button>
  );
}

export default function AdBundle() {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white pb-20">
      {/* Header */}
      <div className="max-w-4xl mx-auto px-4 pt-10 pb-6 text-center">
        <motion.div initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }}>
          <span className="inline-block px-3 py-1 rounded-full bg-yellow-400/10 border border-yellow-400/20 text-yellow-400 text-xs font-semibold uppercase tracking-widest mb-4">
            Social Media Ad Bundle
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold mb-3">
            Ready-to-Post <span className="text-yellow-400">Ad Copy</span>
          </h1>
          <p className="text-gray-400 text-sm max-w-md mx-auto">
            Copy and paste these captions directly into TikTok, Instagram, and Facebook. All include the required Amazon affiliate disclaimer.
          </p>
        </motion.div>
      </div>

      {/* Ad Sections */}
      <div className="max-w-4xl mx-auto px-4 space-y-10">
        {ads.map(({ platform, category, color, bg, border, icon, posts }, pi) => (
          <motion.div
            key={platform}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: pi * 0.1 }}
          >
            {/* Platform Header */}
            <div
              className="flex items-center gap-3 px-5 py-3 rounded-2xl mb-4 border"
              style={{ background: bg, borderColor: border }}
            >
              <span style={{ color }}>{icon}</span>
              <div>
                <p className="font-bold text-white text-sm">{platform}</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>{category}</p>
              </div>
            </div>

            {/* Posts */}
            <div className="space-y-4">
              {posts.map(({ label, text }) => (
                <div
                  key={label}
                  className="rounded-2xl border bg-white/[0.03] p-5"
                  style={{ borderColor: "rgba(255,255,255,0.08)" }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className="text-xs font-semibold px-2.5 py-1 rounded-full border"
                      style={{ color, background: bg, borderColor: border }}
                    >
                      {label}
                    </span>
                    <CopyButton text={text} />
                  </div>
                  <pre className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed font-sans">
                    {text}
                  </pre>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Tips */}
      <div className="max-w-4xl mx-auto px-4 mt-12">
        <div className="rounded-2xl border border-yellow-400/20 bg-yellow-400/5 p-6">
          <h3 className="text-yellow-400 font-bold text-sm uppercase tracking-wider mb-3">📌 Posting Tips</h3>
          <ul className="text-sm text-gray-400 space-y-2 list-disc list-inside">
            <li>On TikTok & Instagram, always add your link in bio and reference it in the caption.</li>
            <li>Post at peak times: 7–9am, 12–2pm, or 7–9pm in your audience's timezone.</li>
            <li>Use a real photo or short video of the product alongside the caption for best results.</li>
            <li>The Amazon affiliate disclaimer is required by law — never remove it.</li>
            <li>Engage with comments within the first 30 minutes to boost reach.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}