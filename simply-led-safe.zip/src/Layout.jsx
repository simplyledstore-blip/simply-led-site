import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "./utils";
import { Menu, X, Zap } from "lucide-react";

export default function Layout({ children, currentPageName }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    // Open Graph + SEO Meta Tags
    const setMeta = (property, content, isName = false) => {
      const attr = isName ? "name" : "property";
      let el = document.querySelector(`meta[${attr}="${property}"]`);
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, property);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };

    document.title = "SimplyLED Store — LED Safety Lights for Night Visibility";
    setMeta("description", "Honest reviews and curated picks for the best LED clip-on safety lights. Stay visible and safe during night walks, runs, cycling, and dog walks.", true);
    setMeta("og:type", "website");
    setMeta("og:url", "https://mysimplyledstore.com/");
    setMeta("og:title", "SimplyLED Store — LED Safety Lights for Night Visibility");
    setMeta("og:description", "Stay visible and safe at night. Curated LED clip-on safety lights for walkers, runners, cyclists, and pets.");
    setMeta("og:image", "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/a7e7fb818_SLS-LOGO1.png");
    setMeta("og:site_name", "SimplyLED Store");
    setMeta("twitter:card", "summary_large_image", true);
    setMeta("twitter:title", "SimplyLED Store — LED Safety Lights for Night Visibility", true);
    setMeta("twitter:description", "Stay visible and safe at night. Curated LED clip-on safety lights for walkers, runners, cyclists, and pets.", true);
    setMeta("twitter:image", "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/a7e7fb818_SLS-LOGO1.png", true);
    setMeta("p:domain_verify", "d9aa21906153a98466c9cb434db0ea61", true);
  }, []);



  const navLinks = [
    { name: "Home", page: "Home" },
    { name: "Joggers", page: "Joggers" },
    { name: "Pets", page: "Pets" },
    { name: "Cyclists", page: "Cyclists" },
    { name: "About Us", page: "AboutUs" },
    { name: "Blog", page: "Blog" },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <style>{`
        :root {
          --accent: #FACC15;
          --accent-glow: rgba(250, 204, 21, 0.15);
        }
        .glow-text {
          text-shadow: 0 0 20px rgba(250, 204, 21, 0.4);
        }
        .glow-border {
          box-shadow: 0 0 15px rgba(250, 204, 21, 0.15);
        }
        .glow-btn:hover {
          box-shadow: 0 0 25px rgba(250, 204, 21, 0.4);
        }
        body {
          background: #0a0a0f;
        }
      `}</style>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0a0a0f]/90 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex items-center group">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/a7e7fb818_SLS-LOGO1.png"
                alt="SimplyLED Store"
                className="h-[38px] sm:h-[48px] w-auto"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.page}
                  to={createPageUrl(link.page)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                    currentPageName === link.page
                      ? "bg-yellow-400/10 text-yellow-400 border border-yellow-400/20"
                      : "text-gray-400 hover:text-white hover:bg-white/5"
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-white/5 bg-[#0a0a0f]/95 backdrop-blur-xl">
            <div className="px-4 py-3 space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.page}
                  to={createPageUrl(link.page)}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`block px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                    currentPageName === link.page
                      ? "bg-yellow-400/10 text-yellow-400"
                      : "text-gray-400 hover:text-white hover:bg-white/5"
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Page Content */}
      <main className="pt-16 sm:pt-20">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-[#060609]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698c28e27df8a2d4f6193df6/1c531f4f3_SLS-LOGO1.png" 
                  alt="SimplyLED Store" 
                  className="h-8 sm:h-10"
                />
              </div>
              <p className="text-sm text-gray-500 leading-relaxed max-w-xs">
                Honest reviews and curated picks for the best LED safety lights. Stay visible, stay safe.
              </p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-300 uppercase tracking-wider mb-4">Quick Links</h4>
              <div className="space-y-2">
                {navLinks.map((link) => (
                  <Link
                    key={link.page}
                    to={createPageUrl(link.page)}
                    className="block text-sm text-gray-500 hover:text-yellow-400 transition-colors"
                  >
                    {link.name}
                  </Link>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-300 uppercase tracking-wider mb-4">Disclosure</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                As an Amazon Associate I earn from qualifying purchases. Product prices and availability are accurate as of the date/time indicated and are subject to change.
              </p>
            </div>
          </div>
          <div className="mt-10 pt-8 border-t border-white/5 text-center">
            <p className="text-xs text-gray-600">
              © {new Date().getFullYear()} SimplyLED Store — simplyledstore.com. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}